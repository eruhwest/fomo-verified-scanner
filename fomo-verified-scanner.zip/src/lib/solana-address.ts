const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

export type MintCheck =
  | { ok: true; mint: string }
  | { ok: false; reason: string };

/** Decode a base58 string. Returns null when a character is outside the alphabet. */
export function decodeBase58(input: string): Uint8Array | null {
  let value = 0n;
  let zeros = 0;
  let sawNonZero = false;

  for (const char of input) {
    const index = ALPHABET.indexOf(char);
    if (index === -1) return null;
    if (!sawNonZero && char === "1") zeros += 1;
    else sawNonZero = true;
    value = value * 58n + BigInt(index);
  }

  if (value === 0n) return new Uint8Array(zeros);

  let hex = value.toString(16);
  if (hex.length % 2 === 1) hex = `0${hex}`;
  const payload = new Uint8Array(hex.length / 2);
  for (let i = 0; i < payload.length; i += 1) {
    payload[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }

  const out = new Uint8Array(zeros + payload.length);
  out.set(payload, zeros);
  return out;
}

/**
 * Format check only. A pass here means the text is a 32-byte Solana address.
 * It does not mean the account exists, is a mint, or passed any check.
 */
export function checkMint(raw: string): MintCheck {
  const mint = raw.trim();
  if (!mint) return { ok: false, reason: "Empty line." };
  if (/\s/.test(mint)) {
    return { ok: false, reason: "One mint per line. This line has extra text." };
  }
  if (mint.length < 32 || mint.length > 44) {
    return { ok: false, reason: "Solana addresses are 32 to 44 base58 characters." };
  }

  const decoded = decodeBase58(mint);
  if (!decoded) {
    return { ok: false, reason: "Contains a character that is not base58 (0, O, I, and l are not used)." };
  }
  if (decoded.length !== 32) {
    return { ok: false, reason: "Does not decode to a 32-byte Solana address." };
  }
  return { ok: true, mint };
}
