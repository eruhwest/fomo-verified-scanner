/** A 1-hour price rise above this percent halves the score. */
export const LATE_CHASER_H1_PCT = 80;

const RISE_CAP = 3;
const LATE_PENALTY = 0.5;

export type MomentumScore = {
  score: number;
  lateChaser: boolean;
  buyerRise: number;
  volumeRise: number;
};

export type MomentumParts = {
  buyers15: number | null;
  buyers60: number | null;
  trades15: number | null;
  trades60: number | null;
  volumeM5Usd: number | null;
  volumeH1Usd: number | null;
  buysM5: number | null;
  sellsM5: number | null;
  priceChangeH1: number | null;
  /** Actual seconds behind the recent buyer and trade counts. Defaults to 15 minutes. */
  recentSeconds?: number;
  /** Actual seconds behind the longer buyer and trade counts. Defaults to 1 hour. */
  baselineSeconds?: number;
};

function usable(value: number | null, allowNegative = false): value is number {
  if (value === null || !Number.isFinite(value)) return false;
  if (allowNegative) return true;
  return value >= 0;
}

function rise(recent: number, baseline: number): number {
  if (baseline <= 0) return recent > 0 ? RISE_CAP : 0;
  return Math.min(RISE_CAP, recent / baseline);
}

function minutes(seconds: number | undefined, fallback: number): number {
  if (seconds === undefined || !Number.isFinite(seconds) || seconds <= 0) return fallback;
  return seconds / 60;
}

export function scoreMomentum(parts: MomentumParts): MomentumScore | null {
  if (
    !usable(parts.buyers15) ||
    !usable(parts.buyers60) ||
    !usable(parts.trades15) ||
    !usable(parts.trades60) ||
    !usable(parts.volumeM5Usd) ||
    !usable(parts.volumeH1Usd) ||
    !usable(parts.buysM5) ||
    !usable(parts.sellsM5) ||
    !usable(parts.priceChangeH1, true)
  ) {
    return null;
  }
  const recentMin = minutes(parts.recentSeconds, 15);
  const baselineMin = minutes(parts.baselineSeconds, 60);
  const buyerRise = rise(parts.buyers15 / recentMin, parts.buyers60 / baselineMin);
  const tradeRise = rise(parts.trades15 / recentMin, parts.trades60 / baselineMin);
  const volumeRise = rise(parts.volumeM5Usd * 12, parts.volumeH1Usd);
  const tape = parts.buysM5 + parts.sellsM5;
  const pressure = tape > 0 ? parts.buysM5 / tape : 0;
  const raw =
    100 *
    (0.4 * (buyerRise / RISE_CAP) +
      0.25 * (tradeRise / RISE_CAP) +
      0.2 * (volumeRise / RISE_CAP) +
      0.15 * pressure);
  const lateChaser = parts.priceChangeH1 > LATE_CHASER_H1_PCT;
  const scored = lateChaser ? raw * LATE_PENALTY : raw;
  return {
    score: Math.round(scored * 10) / 10,
    lateChaser,
    buyerRise,
    volumeRise,
  };
}
