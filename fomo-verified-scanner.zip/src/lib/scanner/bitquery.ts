import { QUOTE_MINTS, WINDOW_LIMIT } from "./config.ts";
import { checkMint } from "../solana-address.ts";
import type { FomoMint, WindowCounts } from "./types.ts";

const QUOTE = new Set<string>(QUOTE_MINTS);

export const FOMO_WINDOWS_QUERY = `query FomoBuyWindows($signer: String!) {
  Solana {
    m15: DEXTradeByTokens(
      limit: {count: ${WINDOW_LIMIT}}
      orderBy: {descendingByField: "buyers"}
      where: {Transaction: {Signer: {is: $signer}}, Trade: {Side: {Type: {is: buy}}, Currency: {MintAddress: {notIn: ["${QUOTE_MINTS[0]}", "${QUOTE_MINTS[1]}"]}}}, Block: {Time: {since_relative: {minutes_ago: 15}}}}
    ) {
      Trade { Currency { Symbol Name MintAddress } }
      trades: count(distinct: Transaction_Signature)
      buyers: count(distinct: Trade_Account_Owner)
    }
    h1: DEXTradeByTokens(
      limit: {count: ${WINDOW_LIMIT}}
      orderBy: {descendingByField: "buyers"}
      where: {Transaction: {Signer: {is: $signer}}, Trade: {Side: {Type: {is: buy}}, Currency: {MintAddress: {notIn: ["${QUOTE_MINTS[0]}", "${QUOTE_MINTS[1]}"]}}}, Block: {Time: {since_relative: {hours_ago: 1}}}}
    ) {
      Trade { Currency { Symbol Name MintAddress } }
      trades: count(distinct: Transaction_Signature)
      buyers: count(distinct: Trade_Account_Owner)
    }
    h6: DEXTradeByTokens(
      limit: {count: ${WINDOW_LIMIT}}
      orderBy: {descendingByField: "buyers"}
      where: {Transaction: {Signer: {is: $signer}}, Trade: {Side: {Type: {is: buy}}, Currency: {MintAddress: {notIn: ["${QUOTE_MINTS[0]}", "${QUOTE_MINTS[1]}"]}}}, Block: {Time: {since_relative: {hours_ago: 6}}}}
    ) {
      Trade { Currency { Symbol Name MintAddress } }
      trades: count(distinct: Transaction_Signature)
      buyers: count(distinct: Trade_Account_Owner)
    }
  }
}`;

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function counts(row: Record<string, unknown>): WindowCounts | null {
  const trades = row.trades;
  const buyers = row.buyers;
  if (typeof trades !== "number" || typeof buyers !== "number") return null;
  if (!Number.isFinite(trades) || !Number.isFinite(buyers) || trades < 0 || buyers < 0) return null;
  return { trades, buyers };
}

function readRow(row: unknown): { mint: string; symbol: string | null; name: string | null; counts: WindowCounts } | null {
  const record = asRecord(row);
  if (!record) return null;
  const trade = asRecord(record.Trade);
  const currency = asRecord(trade?.Currency);
  const mintRaw = currency?.MintAddress;
  if (typeof mintRaw !== "string") return null;
  const checked = checkMint(mintRaw);
  if (!checked.ok || QUOTE.has(checked.mint)) return null;
  const parsed = counts(record);
  if (!parsed) return null;
  const symbol = typeof currency?.Symbol === "string" && currency.Symbol.trim() ? currency.Symbol.trim() : null;
  const name = typeof currency?.Name === "string" && currency.Name.trim() ? currency.Name.trim() : null;
  return { mint: checked.mint, symbol, name, counts: parsed };
}

export function parseFomoWindows(payload: unknown): FomoMint[] {
  const root = asRecord(payload);
  if (Array.isArray(root?.errors) && root.errors.length > 0) {
    throw new Error("Bitquery returned errors for the Fomo query.");
  }
  const data = asRecord(root?.data);
  const solana = asRecord(data?.Solana);
  if (!solana) {
    throw new Error("Bitquery response did not include Solana window data.");
  }

  const byMint = new Map<string, FomoMint>();
  for (const windowName of ["m15", "h1", "h6"] as const) {
    const rows = solana[windowName];
    if (!Array.isArray(rows)) {
      throw new Error(`Bitquery window ${windowName} was missing.`);
    }
    for (const row of rows) {
      const parsed = readRow(row);
      if (!parsed) continue;
      const current = byMint.get(parsed.mint) ?? {
        mint: parsed.mint,
        symbol: parsed.symbol,
        name: parsed.name,
        m15: null,
        h1: null,
        h6: null,
        recentSeconds: 15 * 60,
        baselineSeconds: 60 * 60,
      };
      if (!current.symbol && parsed.symbol) current.symbol = parsed.symbol;
      if (!current.name && parsed.name) current.name = parsed.name;
      current[windowName] = parsed.counts;
      byMint.set(parsed.mint, current);
    }
  }
  return [...byMint.values()];
}
