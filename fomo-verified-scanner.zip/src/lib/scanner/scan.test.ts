import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { parseFomoWindows } from "./bitquery.ts";
import { judgeChain, parseLargestAccounts, parseMintInfo, selectChainMints, type ChainCheck, type LargestAccount } from "./chain.ts";
import { cronAuthorized, FOMO_SIGNER, PUBLIC_SOLANA_RPC, scanIntervalMinutes } from "./config.ts";
import { dexUrl, selectMainPair } from "./dex.ts";
import { fomoMintsFromBuys, parseHeliusTransactions } from "./helius.ts";
import { mergeDiscovered } from "./merge.ts";
import { LATE_CHASER_H1_PCT, scoreMomentum, type MomentumParts } from "./momentum.ts";
import { readAnnounced, takeFreshMatches, writeAnnounced } from "./notices.ts";
import { OUTCOME_MARKS, applyOutcomes, parseOutcomeFile, toOutcomeRows } from "./outcomes.ts";
import { judgeRoundTrip, TEN_USDC, type QuoteCheck } from "./quotes.ts";
import { judgeRug, type RugCheck } from "./rug.ts";
import type { FomoMint } from "./types.ts";

const BONK = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263";
const USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";

function row(mint: string, trades: number, buyers: number) {
  return {
    Trade: { Currency: { Symbol: "T", Name: "Token", MintAddress: mint } },
    trades,
    buyers,
  };
}

describe("parseFomoWindows", () => {
  it("merges three windows and drops quote mints and broken rows", () => {
    const parsed = parseFomoWindows({
      data: {
        Solana: {
          m15: [row(BONK, 4, 3), row(USDC, 9, 9), { Trade: { Currency: { MintAddress: BONK } } }],
          h1: [row(BONK, 10, 7)],
          h6: [row(BONK, 20, 11)],
        },
      },
    });
    assert.equal(parsed.length, 1);
    assert.equal(parsed[0]?.mint, BONK);
    assert.deepEqual(parsed[0]?.m15, { trades: 4, buyers: 3 });
    assert.deepEqual(parsed[0]?.h6, { trades: 20, buyers: 11 });
  });

  it("fails closed when the payload is an error or a window is missing", () => {
    assert.throws(() => parseFomoWindows({ errors: [{ message: "no" }] }));
    assert.throws(() => parseFomoWindows({ data: { Solana: { m15: [], h1: [] } } }));
  });
});

const USER = "D6VWFG9us9cX6y64n3v1NGQ4WAfTppDoizVKGAPzRvpc";
const POOL = "GpMZbSM2GgvTKHJirzeGfMFoaZ8UR2X7F4v8vHTvxFbL";

function heliusTx(
  time: number,
  balances: { owner: string; mint: string; before: string; after: string }[],
  failed = false,
) {
  return {
    blockTime: time,
    transaction: {
      signatures: [`sig${time}`],
      message: {
        accountKeys: [
          { pubkey: FOMO_SIGNER, signer: true },
          { pubkey: USER, signer: true },
          { pubkey: POOL, signer: false },
        ],
      },
    },
    meta: {
      err: failed ? { InstructionError: [0, "x"] } : null,
      preTokenBalances: balances.map((row) => ({
        owner: row.owner,
        mint: row.mint,
        uiTokenAmount: { amount: row.before },
      })),
      postTokenBalances: balances.map((row) => ({
        owner: row.owner,
        mint: row.mint,
        uiTokenAmount: { amount: row.after },
      })),
    },
  };
}

describe("Helius Fomo reads", () => {
  it("counts a signer token increase and ignores quote mints, pools, and sells", () => {
    const page = parseHeliusTransactions({
      result: {
        data: [
          heliusTx(1_000, [
            { owner: USER, mint: BONK, before: "1", after: "5" },
            { owner: USER, mint: USDC, before: "9", after: "0" },
            { owner: POOL, mint: BONK, before: "50", after: "40" },
          ]),
          heliusTx(1_001, [{ owner: USER, mint: BONK, before: "5", after: "1" }]),
          heliusTx(1_002, [{ owner: USER, mint: BONK, before: "1", after: "2" }], true),
        ],
      },
    });
    assert.equal(page.transactionCount, 3);
    assert.equal(page.events.length, 1);
    assert.equal(page.events[0]?.mint, BONK);
    assert.equal(page.events[0]?.buyer, USER);
  });

  it("fails closed on an error or a missing transaction list", () => {
    assert.throws(() => parseHeliusTransactions({ error: { message: "no" } }));
    assert.throws(() => parseHeliusTransactions({ result: {} }));
  });

  it("labels a short page as a sample and a long page as clock windows", () => {
    const now = 10_000;
    const sampleEvents = [
      { signature: "a", blockTime: now - 180, mint: BONK, buyer: USER },
      { signature: "b", blockTime: now - 30, mint: BONK, buyer: "Sysvar1111111111111111111111111111111111111" },
    ];
    const sample = fomoMintsFromBuys(sampleEvents, now - 180, now, now, 2);
    assert.match(sample.note, /not a full 15-minute/);
    assert.equal(sample.mints[0]?.h1?.trades, 2);
    assert.equal(sample.mints[0]?.m15?.trades, 1);
    assert.ok((sample.mints[0]?.baselineSeconds ?? 0) < 900);

    const clock = fomoMintsFromBuys(
      [
        { signature: "old", blockTime: now - 3000, mint: BONK, buyer: USER },
        { signature: "new", blockTime: now - 60, mint: BONK, buyer: USER },
      ],
      now - 7200,
      now,
      now,
      4,
    );
    assert.match(clock.note, /at least 1 hour/);
    assert.equal(clock.mints[0]?.m15?.trades, 1);
    assert.equal(clock.mints[0]?.h1?.trades, 2);
    assert.equal(clock.mints[0]?.h6, null);
    assert.equal(clock.mints[0]?.recentSeconds, 900);
  });
});

describe("selectMainPair", () => {
  it("keeps the pool with more liquidity and ignores other mints", () => {
    const pair = selectMainPair(BONK, [
      {
        url: "https://dexscreener.com/solana/small",
        baseToken: { address: BONK, name: "Bonk", symbol: "Bonk" },
        priceUsd: "0.000002",
        liquidity: { usd: 1000 },
        volume: { m5: 10 },
        txns: { m5: { buys: 1, sells: 2 } },
        marketCap: 5,
        pairCreatedAt: 1_700_000_000_000,
        info: { socials: [{ type: "twitter", url: "https://twitter.com/bonk_inu" }] },
      },
      {
        url: "https://example.com/not-dex",
        baseToken: { address: BONK, name: "Bonk", symbol: "Bonk" },
        priceUsd: "0.000003",
        liquidity: { usd: 50_000, base: 12_345 },
        volume: { m5: 80, h1: 900 },
        priceChange: { h1: 4.5 },
        txns: { m5: { buys: 4, sells: 1 } },
      },
      {
        url: "https://dexscreener.com/solana/other",
        baseToken: { address: USDC, symbol: "USDC" },
        liquidity: { usd: 9_000_000 },
      },
    ]);
    assert.equal(pair?.liquidityUsd, 50_000);
    assert.equal(pair?.pairUrl, `https://dexscreener.com/solana/${BONK}`);
    assert.equal(pair?.volumeM5Usd, 80);
    assert.equal(pair?.volumeH1Usd, 900);
    assert.equal(pair?.priceChangeH1, 4.5);
    assert.equal(pair?.buysM5, 4);
    assert.equal(pair?.poolBase, 12_345);
    assert.deepEqual(pair?.socials, []);
  });

  it("returns null when no pool has liquidity", () => {
    assert.equal(selectMainPair(BONK, [{ baseToken: { address: BONK }, liquidity: {} }]), null);
  });

  it("rejects a non-list payload", () => {
    assert.throws(() => selectMainPair(BONK, { pairs: [] }));
  });
});

describe("mergeDiscovered", () => {
  it("hides a mint with no pool and keeps Fomo counts on a priced mint", () => {
    const fomo: FomoMint[] = [
      { mint: BONK, symbol: "Bonk", name: "Bonk", m15: { trades: 30, buyers: 20 }, h1: { trades: 40, buyers: 30 }, h6: null, recentSeconds: 900, baselineSeconds: 3600 },
      {
        mint: USDC,
        symbol: "USDC",
        name: "USD Coin",
        m15: null,
        h1: { trades: 1, buyers: 1 },
        h6: null,
        recentSeconds: 900,
        baselineSeconds: 3600,
      },
    ];
    const pairs = new Map([
      [
        BONK,
        {
          mint: BONK,
          name: "Bonk",
          symbol: "Bonk",
          pairUrl: "https://dexscreener.com/solana/bonk",
          priceUsd: 0.000003,
          liquidityUsd: 300_000,
          marketCapUsd: 100,
          volumeM5Usd: 12,
          volumeH1Usd: 100,
          priceChangeH1: 4,
          buysM5: 3,
          sellsM5: 1,
          pairCreatedAt: 1,
          socials: [],
          poolBase: 1_000,
        },
      ],
      [USDC, null],
    ]);
    const chains = new Map<string, ChainCheck>([
      [BONK, { status: "pass", reason: "pass", largestHolderPct: 0.02, top10Pct: 0.1 }],
    ]);
    const quotes = new Map<string, QuoteCheck>([
      [BONK, { status: "pass", reason: "pass", sellReturnPct: 0.99 }],
    ]);
    const rugs = new Map<string, RugCheck>([[BONK, { status: "pass", reason: "pass", score: 101 }]]);
    const merged = mergeDiscovered(fomo, pairs, [], chains, quotes, rugs);
    assert.equal(merged.scanned, 2);
    assert.equal(merged.hidden, 1);
    assert.equal(merged.discovered.length, 1);
    assert.equal(merged.discovered[0]?.source, "fomo");
    assert.equal(merged.discovered[0]?.fomo.m15?.buyers, 20);
    assert.equal(merged.discovered[0]?.largestHolderPct, 0.02);
    assert.equal(merged.discovered[0]?.sellReturnPct, 0.99);
    assert.equal(merged.discovered[0]?.rugScore, 101);
    assert.ok((merged.discovered[0]?.momentumScore ?? 0) > 0);
  });

  it("hides a pooled mint when the chain check did not pass", () => {
    const pairs = new Map([
      [
        BONK,
        {
          mint: BONK,
          name: "Bonk",
          symbol: "Bonk",
          pairUrl: "https://dexscreener.com/solana/bonk",
          priceUsd: 1,
          liquidityUsd: 1,
          marketCapUsd: 1,
          volumeM5Usd: 1,
          volumeH1Usd: 10,
          priceChangeH1: 1,
          buysM5: 1,
          sellsM5: 1,
          pairCreatedAt: 1,
          socials: [],
          poolBase: 1,
        },
      ],
    ]);
    const chains = new Map<string, ChainCheck>([
      [BONK, { status: "hide", reason: "mint", largestHolderPct: null, top10Pct: null }],
    ]);
    const quotes = new Map<string, QuoteCheck>([
      [BONK, { status: "hide", reason: "sell", sellReturnPct: 0.7 }],
    ]);
    const rugs = new Map<string, RugCheck>([[BONK, { status: "pass", reason: "pass", score: 10 }]]);
    const merged = mergeDiscovered([], pairs, [BONK], chains, quotes, rugs);
    assert.equal(merged.hidden, 1);
    assert.equal(merged.discovered.length, 0);
  });

  it("hides a pool under $10,000", () => {
    const pairs = new Map([
      [
        BONK,
        {
          mint: BONK,
          name: "Bonk",
          symbol: "Bonk",
          pairUrl: "https://dexscreener.com/solana/bonk",
          priceUsd: 1,
          liquidityUsd: 9_999,
          marketCapUsd: 1,
          volumeM5Usd: 1,
          volumeH1Usd: 10,
          priceChangeH1: 1,
          buysM5: 1,
          sellsM5: 1,
          pairCreatedAt: 1,
          socials: [],
          poolBase: 1,
        },
      ],
    ]);
    const chains = new Map<string, ChainCheck>([
      [BONK, { status: "pass", reason: "pass", largestHolderPct: 0.01, top10Pct: 0.1 }],
    ]);
    const quotes = new Map<string, QuoteCheck>([[BONK, { status: "pass", reason: "pass", sellReturnPct: 0.99 }]]);
    const rugs = new Map<string, RugCheck>([[BONK, { status: "pass", reason: "pass", score: 1 }]]);
    const fomo: FomoMint[] = [
      { mint: BONK, symbol: "Bonk", name: "Bonk", m15: { trades: 10, buyers: 10 }, h1: { trades: 10, buyers: 10 }, h6: null, recentSeconds: 900, baselineSeconds: 3600 },
    ];
    const merged = mergeDiscovered(fomo, pairs, [], chains, quotes, rugs);
    assert.equal(merged.hidden, 1);
    assert.equal(merged.discovered.length, 0);
  });
});

describe("scan config", () => {
  it("clamps the interval and refuses a cron call without the secret", () => {
    assert.equal(scanIntervalMinutes(undefined), 30);
    assert.equal(scanIntervalMinutes("1"), 15);
    assert.equal(scanIntervalMinutes("500"), 180);
    assert.equal(cronAuthorized("Bearer secret", "secret"), true);
    assert.equal(cronAuthorized("Bearer secret", undefined), false);
    assert.equal(cronAuthorized(null, "secret"), false);
  });
});

describe("on-chain gates", () => {
  const accounts = [
    "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    "So11111111111111111111111111111111111111112",
    "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
    "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb",
    "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL",
    "11111111111111111111111111111111",
    "ComputeBudget111111111111111111111111111111",
    "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr",
    "JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4",
    "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc",
    "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8",
  ];
  const wallet = "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM";
  const system = "11111111111111111111111111111111";
  const burn = "1nc1nerator11111111111111111111111111111111";
  const locker = "strmRqUCoQUgGUan5YhzUZa6KqdzwX5L6FpUxfmKg5m";

  function judge(rows: { amount: bigint; owner: string; program: string | null }[], poolBase: number | null, mintAuthority: string | null = null, freezeAuthority: string | null = null) {
    const largest: LargestAccount[] = rows.map((row, index) => ({
      address: accounts[index] ?? wallet,
      amount: row.amount,
      uiAmount: Number(row.amount),
    }));
    const owners = new Map(rows.map((row, index) => [accounts[index] ?? wallet, row.owner]));
    const programs = new Map<string, string | null>();
    for (const row of rows) programs.set(row.owner, row.program);
    return judgeChain({
      mint: { supply: 1_000_000n, mintAuthority, freezeAuthority },
      largest,
      owners,
      programs,
      poolBase,
    });
  }

  it("hides an active mint or freeze authority", () => {
    const rows = [{ amount: 100_000n, owner: wallet, program: system }];
    assert.equal(judge(rows, 100_000, wallet, null).reason, "mint");
    assert.equal(judge(rows, 100_000, null, wallet).reason, "freeze");
  });

  it("hides a holder above 3% and a top 10 above 25%", () => {
    const pool = { amount: 100_000n, owner: "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8", program: system };
    const whale = judge(
      [pool, { amount: 31_000n, owner: wallet, program: system }],
      100_000,
    );
    assert.equal(whale.reason, "holder");
    const wide = judge(
      [
        pool,
        ...accounts.slice(0, 10).map((owner) => ({ amount: 26_000n, owner, program: system })),
      ],
      100_000,
    );
    assert.equal(wide.reason, "top10");
  });

  it("passes when the pool and burn are excluded and the rest stay under both limits", () => {
    const passed = judge(
      [
        { amount: 100_000n, owner: "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8", program: system },
        { amount: 400_000n, owner: burn, program: system },
        { amount: 200_000n, owner: "Escrow11111111111111111111111111111111111", program: locker },
        { amount: 20_000n, owner: wallet, program: system },
      ],
      100_000,
    );
    assert.equal(passed.status, "pass");
    assert.equal(passed.largestHolderPct, 0.02);
    const closedWallet = judge(
      [
        { amount: 100_000n, owner: "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8", program: system },
        { amount: 20_000n, owner: wallet, program: null },
      ],
      100_000,
    );
    assert.equal(closedWallet.status, "pass");
    assert.equal(closedWallet.largestHolderPct, 0.02);
  });

  it("hides when the pool cannot be identified, and passes when the pool is smaller than the sample", () => {
    const rows = [{ amount: 10_000n, owner: wallet, program: system }];
    assert.equal(judge(rows, 10_500).reason, "unavailable");
    assert.equal(judge([{ amount: 20_000n, owner: wallet, program: system }], 1_000).status, "pass");
    assert.equal(judgeChain({ mint: null, largest: null, owners: null, programs: null, poolBase: 1 }).reason, "unavailable");
  });

  it("checks pasted mints first and leaves the overflow unchecked", () => {
    const paired = new Set(accounts);
    const queue = selectChainMints([accounts[5] ?? ""], accounts.map((mint) => ({ mint, m15: null, h1: { buyers: 1 } })), paired, 2);
    assert.deepEqual(queue.selected, [accounts[5], accounts[0]]);
    assert.equal(queue.skipped, accounts.length - 2);
  });

  it("reads a parsed mint account", () => {
    const parsed = parseMintInfo({
      data: {
        parsed: {
          type: "mint",
          info: { supply: "1000", decimals: 5, mintAuthority: null, freezeAuthority: null, isInitialized: true },
        },
      },
    });
    assert.equal(parsed?.supply, 1000n);
    assert.equal(parsed?.mintAuthority, null);
    assert.equal(parseMintInfo({ data: { parsed: { type: "account", info: {} } } }), null);
  });
});

describe("sell quote and RugCheck", () => {
  const spent = TEN_USDC;
  const bought = { inAmount: spent, outAmount: 1_000n };

  it("hides a sell quote under 80% and passes one at 80% or more", () => {
    const weak = judgeRoundTrip(spent, bought, { inAmount: 1_000n, outAmount: 7_999_999n });
    assert.equal(weak.reason, "sell");
    const even = judgeRoundTrip(spent, bought, { inAmount: 1_000n, outAmount: 8_000_000n });
    assert.equal(even.status, "pass");
    assert.equal(even.sellReturnPct, 0.8);
    assert.equal(judgeRoundTrip(spent, null, null).reason, "unavailable");
  });

  it("hides a high score, a honeypot, a rugged flag, or an authority warning", () => {
    const clean = {
      score: 101,
      rugged: false,
      mintAuthority: null,
      freezeAuthority: null,
      risks: [{ name: "Mutable metadata", level: "warn", description: "Token metadata can be changed" }],
    };
    assert.equal(judgeRug(clean).status, "pass");
    assert.equal(judgeRug({ ...clean, score: 5000 }).reason, "score");
    assert.equal(judgeRug({ ...clean, risks: [{ name: "Honeypot", level: "danger", description: "Sells fail" }] }).reason, "honeypot");
    assert.equal(judgeRug({ ...clean, rugged: true }).reason, "honeypot");
    assert.equal(
      judgeRug({
        ...clean,
        risks: [{ name: "Mint Authority still enabled", level: "danger", description: "The minter can create more" }],
      }).reason,
      "authority",
    );
    assert.equal(judgeRug({ score: 1 }).reason, "unavailable");
  });
});

describe("momentum score", () => {
  const base: MomentumParts = {
    buyers15: 30,
    buyers60: 40,
    trades15: 30,
    trades60: 40,
    volumeM5Usd: 100,
    volumeH1Usd: 1_200,
    buysM5: 8,
    sellsM5: 2,
    priceChangeH1: 10,
  };

  it("ranks a token with rising buyers above one with fading volume", () => {
    const rising = scoreMomentum(base);
    const fading = scoreMomentum({
      ...base,
      buyers15: 2,
      buyers60: 40,
      trades15: 2,
      trades60: 40,
      volumeM5Usd: 5,
      volumeH1Usd: 5_000,
    });
    assert.ok(rising && fading && rising.score > fading.score);
  });

  it("penalizes a token already up more than the late-chaser limit", () => {
    const atLimit = scoreMomentum({ ...base, priceChangeH1: LATE_CHASER_H1_PCT });
    const over = scoreMomentum({ ...base, priceChangeH1: LATE_CHASER_H1_PCT + 20 });
    assert.equal(atLimit?.lateChaser, false);
    assert.equal(over?.lateChaser, true);
    assert.ok(atLimit && over && over.score < atLimit.score);
    assert.ok(Math.abs((over?.score ?? 0) - (atLimit?.score ?? 0) * 0.5) <= 0.1);
  });

  it("returns no score when buyer or price-change data is missing", () => {
    assert.equal(scoreMomentum({ ...base, buyers60: null }), null);
    assert.equal(scoreMomentum({ ...base, priceChangeH1: null }), null);
  });
});

describe("outcome tracker", () => {
  const seen = 1_700_000_000_000;
  const sight = { mint: BONK, symbol: "Bonk", name: "Bonk", priceUsd: 1 };

  it("records an entry price, then fills 1h, 6h, and 24h without moving the entry", () => {
    const opened = applyOutcomes([], [sight], new Map([[BONK, 1]]), seen);
    assert.equal(opened.length, 1);
    assert.equal(opened[0]?.entryPriceUsd, 1);
    assert.equal(opened[0]?.h1, null);
    assert.equal(opened[0]?.h6, null);
    assert.equal(opened[0]?.h24, null);

    const early = applyOutcomes(opened, [], new Map([[BONK, 9]]), seen + OUTCOME_MARKS.h1 - 1);
    assert.equal(early[0]?.h1, null);
    assert.equal(early[0]?.entryPriceUsd, 1);

    const hour = applyOutcomes(early, [], new Map([[BONK, 1.5]]), seen + OUTCOME_MARKS.h1);
    assert.equal(hour[0]?.h1?.priceUsd, 1.5);
    assert.equal(hour[0]?.h6, null);
    assert.equal(hour[0]?.entryPriceUsd, 1);

    const six = applyOutcomes(hour, [], new Map([[BONK, 0.5]]), seen + OUTCOME_MARKS.h6);
    assert.equal(six[0]?.h1?.priceUsd, 1.5);
    assert.equal(six[0]?.h6?.priceUsd, 0.5);
    assert.equal(six[0]?.h24, null);

    const day = applyOutcomes(six, [{ ...sight, priceUsd: 4 }], new Map([[BONK, 3]]), seen + OUTCOME_MARKS.h24);
    assert.equal(day.length, 1);
    assert.equal(day[0]?.entryPriceUsd, 1);
    assert.equal(day[0]?.h24?.priceUsd, 3);
    const rows = toOutcomeRows(day, seen + OUTCOME_MARKS.h24);
    assert.equal(rows[0]?.h1.state, "set");
    if (rows[0]?.h1.state === "set") assert.equal(rows[0].h1.changePct, 0.5);
    if (rows[0]?.h6.state === "set") assert.equal(rows[0].h6.changePct, -0.5);
    if (rows[0]?.h24.state === "set") assert.equal(rows[0].h24.changePct, 2);
  });

  it("leaves a due checkpoint empty when the price is missing", () => {
    const opened = applyOutcomes([], [sight], new Map([[BONK, 1]]), seen);
    const missed = applyOutcomes(opened, [], new Map(), seen + OUTCOME_MARKS.h1 + 60_000);
    assert.equal(missed[0]?.h1, null);
    const rows = toOutcomeRows(missed, seen + OUTCOME_MARKS.h1 + 60_000);
    assert.equal(rows[0]?.h1.state, "waiting");
    assert.equal(parseOutcomeFile([{ mint: "not-an-address", entryPriceUsd: 1, seenAt: seen }]).length, 0);
  });
});

describe("live DexScreener", () => {
  it("reads a real Bonk pool", async () => {
    const response = await fetch(dexUrl([BONK]), { headers: { accept: "application/json" } });
    assert.equal(response.ok, true);
    const payload: unknown = await response.json();
    const pair = selectMainPair(BONK, payload);
    assert.ok(pair);
    assert.equal(pair?.mint, BONK);
    assert.ok((pair?.liquidityUsd ?? 0) > 0);
    assert.equal(pair?.symbol, "Bonk");
    assert.ok(pair?.socials.some((link) => link.url.startsWith("https://")));
    assert.ok((pair?.poolBase ?? 0) > 0);
  });
});

describe("live Solana RPC", () => {
  async function rpc(method: string, params: unknown[]): Promise<unknown> {
    let last = "Solana RPC request failed.";
    for (let attempt = 0; attempt < 4; attempt += 1) {
      const response = await fetch(PUBLIC_SOLANA_RPC, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
      });
      if (response.status === 429 || response.status >= 500) {
        last = `HTTP ${response.status}`;
        await new Promise((resolve) => setTimeout(resolve, 700 * (attempt + 1)));
        continue;
      }
      assert.equal(response.ok, true);
      const payload: unknown = await response.json();
      const record = payload as { result?: { value?: unknown }; error?: unknown };
      assert.equal(record.error, undefined);
      return record.result?.value;
    }
    throw new Error(last);
  }

  it("reads a revoked Bonk mint and hides USDC while an authority is set", async () => {
    const bonk = parseMintInfo(await rpc("getAccountInfo", [BONK, { encoding: "jsonParsed" }]));
    assert.equal(bonk?.mintAuthority, null);
    assert.equal(bonk?.freezeAuthority, null);
    await new Promise((resolve) => setTimeout(resolve, 400));
    const usdc = parseMintInfo(await rpc("getAccountInfo", [USDC, { encoding: "jsonParsed" }]));
    assert.ok(usdc?.mintAuthority);
    assert.ok(usdc?.freezeAuthority);
    const hidden = judgeChain({ mint: usdc, largest: null, owners: null, programs: null, poolBase: 1 });
    assert.equal(hidden.status, "hide");
    assert.equal(hidden.reason, "mint");
    await new Promise((resolve) => setTimeout(resolve, 400));
    const largest = await rpc("getTokenLargestAccounts", [BONK, { commitment: "confirmed" }]);
    const parsed = parseLargestAccounts(largest);
    assert.ok(parsed && parsed.length === 20);
  });
});

describe("live Jupiter and RugCheck", () => {
  it("quotes a $10 Bonk round trip at 80% or more and reads a RugCheck score under 5,000", async () => {
    const { checkRoundTrip, checkRug } = await import("./markets.server.ts");
    const quote = await checkRoundTrip(BONK);
    assert.equal(quote.status, "pass");
    assert.ok((quote.sellReturnPct ?? 0) >= 0.8);
    const rug = await checkRug(BONK);
    assert.equal(rug.status, "pass");
    assert.ok((rug.score ?? 5000) < 5000);
  });
});

describe("match notices", () => {
  it("announces a new mint once, then again only after it leaves the feed", () => {
    const seen = new Set<string>();
    const first = takeFreshMatches(seen, [{ mint: BONK }]);
    assert.deepEqual(first.map((token) => token.mint), [BONK]);
    assert.deepEqual(takeFreshMatches(seen, [{ mint: BONK }]), []);
    assert.deepEqual(takeFreshMatches(seen, []), []);
    const again = takeFreshMatches(seen, [{ mint: BONK }]);
    assert.deepEqual(again.map((token) => token.mint), [BONK]);
  });

  it("drops a corrupt saved mint", () => {
    const storage = {
      value: JSON.stringify([BONK, "not-a-mint"]),
      getItem() {
        return this.value;
      },
      setItem(_key: string, value: string) {
        this.value = value;
      },
    };
    const seen = readAnnounced(storage);
    assert.deepEqual([...seen], [BONK]);
    takeFreshMatches(seen, []);
    writeAnnounced(storage, seen);
    assert.deepEqual(JSON.parse(storage.value), []);
  });
});
