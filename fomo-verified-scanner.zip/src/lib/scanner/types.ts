import type { OutcomeCell, OutcomeRow } from "./outcomes.ts";

export type { OutcomeCell, OutcomeRow };

export type WindowCounts = {
  trades: number;
  buyers: number;
};

export type FomoMint = {
  mint: string;
  symbol: string | null;
  name: string | null;
  m15: WindowCounts | null;
  h1: WindowCounts | null;
  h6: WindowCounts | null;
  /** Seconds the m15 counts actually cover. 900 when the read reached 15 minutes. */
  recentSeconds: number;
  /** Seconds the h1 counts actually cover. 3600 when the read reached 1 hour. */
  baselineSeconds: number;
};

export type SocialLink = {
  label: string;
  url: string;
};

export type MarketPair = {
  mint: string;
  name: string | null;
  symbol: string | null;
  pairUrl: string;
  priceUsd: number | null;
  liquidityUsd: number;
  marketCapUsd: number | null;
  volumeM5Usd: number | null;
  volumeH1Usd: number | null;
  /** 1-hour price change in percent. Null when DexScreener did not send it. */
  priceChangeH1: number | null;
  buysM5: number | null;
  sellsM5: number | null;
  pairCreatedAt: number | null;
  socials: SocialLink[];
  /** Base-token amount in this pool. Null when DexScreener did not send it. */
  poolBase: number | null;
};

export type DiscoveredToken = {
  mint: string;
  name: string | null;
  symbol: string | null;
  source: "fomo" | "list" | "both";
  pairUrl: string;
  priceUsd: number | null;
  liquidityUsd: number;
  marketCapUsd: number | null;
  volumeM5Usd: number | null;
  volumeH1Usd: number;
  priceChangeH1: number;
  buysM5: number | null;
  sellsM5: number | null;
  pairCreatedAt: number | null;
  fomo: {
    m15: WindowCounts | null;
    h1: WindowCounts | null;
    h6: WindowCounts | null;
  };
  socials: SocialLink[];
  largestHolderPct: number;
  top10Pct: number;
  sellReturnPct: number;
  rugScore: number;
  momentumScore: number;
  lateChaser: boolean;
  buyerRise: number;
  volumeRise: number;
  recentSeconds: number;
  baselineSeconds: number;
};

export type ServiceError = {
  source: "helius" | "dexscreener" | "solana" | "jupiter" | "rugcheck" | "outcomes";
  message: string;
};

export type ScanSnapshot = {
  scannedAt: string | null;
  stale: boolean;
  intervalMinutes: number;
  bitqueryConfigured: boolean;
  /** How the buyer counts were built. Null when discovery did not run. */
  discoveryNote: string | null;
  tokensScanned: number;
  fomoMints: number;
  hiddenByGates: number;
  serviceErrors: ServiceError[];
  discovered: DiscoveredToken[];
  outcomes: OutcomeRow[];
};
