/** Documented Fomo Solana fee-payer. Source: Bitquery Fomo API docs, checked 2026-10-26. */
export const FOMO_SIGNER = "AgmLJBMDCqWynYnQiPCuj9ewsNNsBJXyzoUhD9LJzN51";

/** Quote mints excluded by Bitquery's own Fomo token query. */
export const QUOTE_MINTS = [
  "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  "So11111111111111111111111111111111111111112",
] as const;

export const BITQUERY_URL = "https://streaming.bitquery.io/graphql";
export const DEX_TOKEN_URL = "https://api.dexscreener.com/tokens/v1/solana";

/** Public RPC that answered getTokenLargestAccounts. Override with SOLANA_RPC_URL. */
export const PUBLIC_SOLANA_RPC = "https://public.rpc.solanavibestation.com";

/** Pools under this USD liquidity are hidden. */
export const MIN_LIQUIDITY_USD = 10_000;

/** How many pooled tokens get on-chain checks per refresh. Keeps the public RPC quiet. */
export const CHAIN_BATCH = 8;

/** Top mints per window. Bitquery's sample uses 10; 40 keeps one request small. */
export const WINDOW_LIMIT = 40;

/** One scan is one GraphQL call. Used while a server process stays up. */
export const DEFAULT_SCAN_MINUTES = 30;
export const MIN_SCAN_MINUTES = 15;
export const MAX_SCAN_MINUTES = 180;

export function scanIntervalMinutes(raw: string | undefined): number {
  const parsed = Number(raw);
  if (!Number.isFinite(parsed)) return DEFAULT_SCAN_MINUTES;
  return Math.min(MAX_SCAN_MINUTES, Math.max(MIN_SCAN_MINUTES, Math.round(parsed)));
}

export function cronAuthorized(header: string | null, secret: string | undefined): boolean {
  if (!secret) return false;
  return header === `Bearer ${secret}`;
}
