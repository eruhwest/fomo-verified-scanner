import { FOMO_SIGNER, QUOTE_MINTS, WINDOW_LIMIT } from "./config.ts";
import { checkMint } from "../solana-address.ts";
import type { FomoMint } from "./types.ts";

const QUOTE = new Set<string>(QUOTE_MINTS);
const HOUR = 60 * 60;
const SIX_HOURS = 6 * HOUR;
const FIFTEEN_MIN = 15 * 60;
const MIN_SAMPLE_SECONDS = 60;

export type BuyEvent = {
  signature: string;
  blockTime: number;
  mint: string;
  buyer: string;
};

export type HeliusPage = {
  events: BuyEvent[];
  oldestBlockTime: number | null;
  newestBlockTime: number | null;
  paginationToken: string | null;
  transactionCount: number;
};

export type FomoRead = {
  mints: FomoMint[];
  note: string;
};

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function pubkeyOf(key: unknown): string | null {
  if (typeof key === "string" && key.length > 0) return key;
  const record = asRecord(key);
  return typeof record?.pubkey === "string" && record.pubkey.length > 0 ? record.pubkey : null;
}

function rawAmount(row: Record<string, unknown> | undefined): bigint | null {
  if (!row) return 0n;
  const ui = asRecord(row.uiTokenAmount);
  const amount = ui?.amount;
  if (typeof amount !== "string" || !/^\d+$/.test(amount)) return null;
  return BigInt(amount);
}

function countWindow(events: readonly BuyEvent[], from: number, to: number): Map<string, { trades: Set<string>; buyers: Set<string> }> {
  const byMint = new Map<string, { trades: Set<string>; buyers: Set<string> }>();
  for (const event of events) {
    if (event.blockTime < from || event.blockTime > to) continue;
    const row = byMint.get(event.mint) ?? { trades: new Set<string>(), buyers: new Set<string>() };
    row.trades.add(event.signature);
    row.buyers.add(event.buyer);
    byMint.set(event.mint, row);
  }
  return byMint;
}

export function parseHeliusTransactions(payload: unknown): HeliusPage {
  const root = asRecord(payload);
  if (!root) throw new Error("Helius response was not an object.");
  if (root.error) throw new Error("Helius rejected the Fomo history request.");
  const result = asRecord(root.result);
  const data = Array.isArray(result?.data) ? result.data : Array.isArray(root.result) ? root.result : null;
  if (!data) throw new Error("Helius response did not include transactions.");

  const events: BuyEvent[] = [];
  let oldest: number | null = null;
  let newest: number | null = null;
  for (const item of data) {
    const tx = asRecord(item);
    if (!tx) continue;
    const meta = asRecord(tx.meta);
    if (!meta || meta.err != null) continue;
    const blockTime = tx.blockTime;
    if (typeof blockTime !== "number" || !Number.isFinite(blockTime)) continue;
    oldest = oldest === null ? blockTime : Math.min(oldest, blockTime);
    newest = newest === null ? blockTime : Math.max(newest, blockTime);

    const message = asRecord(asRecord(tx.transaction)?.message);
    const keys = Array.isArray(message?.accountKeys) ? message.accountKeys : null;
    const signature = Array.isArray(asRecord(tx.transaction)?.signatures)
      ? (asRecord(tx.transaction)?.signatures as unknown[])[0]
      : null;
    if (!keys || keys.length === 0 || typeof signature !== "string") continue;
    if (pubkeyOf(keys[0]) !== FOMO_SIGNER) continue;
    const signers = new Set<string>();
    let sawSignerFlag = false;
    for (const key of keys) {
      const record = asRecord(key);
      if (record && typeof record.signer === "boolean") sawSignerFlag = true;
      if (record?.signer === true) {
        const pubkey = pubkeyOf(key);
        if (pubkey && pubkey !== FOMO_SIGNER) signers.add(pubkey);
      }
    }
    if (!sawSignerFlag || signers.size === 0) continue;

    const pre = Array.isArray(meta.preTokenBalances) ? meta.preTokenBalances : [];
    const post = Array.isArray(meta.postTokenBalances) ? meta.postTokenBalances : [];
    const before = new Map<string, bigint>();
    const after = new Map<string, bigint>();
    const remember = (rows: unknown[], target: Map<string, bigint>) => {
      for (const row of rows) {
        const record = asRecord(row);
        if (!record || typeof record.owner !== "string" || typeof record.mint !== "string") continue;
        const amount = rawAmount(record);
        if (amount === null) continue;
        target.set(`${record.owner}\n${record.mint}`, amount);
      }
    };
    remember(pre, before);
    remember(post, after);
    const ids = new Set([...before.keys(), ...after.keys()]);
    for (const id of ids) {
      const split = id.indexOf("\n");
      const owner = id.slice(0, split);
      const mint = id.slice(split + 1);
      if (!signers.has(owner)) continue;
      const checked = checkMint(mint);
      if (!checked.ok || QUOTE.has(checked.mint)) continue;
      const delta = (after.get(id) ?? 0n) - (before.get(id) ?? 0n);
      if (delta <= 0n) continue;
      events.push({ signature, blockTime, mint: checked.mint, buyer: owner });
    }
  }

  const token = result?.paginationToken;
  return {
    events,
    oldestBlockTime: oldest,
    newestBlockTime: newest,
    paginationToken: typeof token === "string" && token.length > 0 ? token : null,
    transactionCount: data.length,
  };
}

function toMints(
  events: readonly BuyEvent[],
  recentFrom: number,
  recentTo: number,
  baselineFrom: number,
  baselineTo: number,
  sixFrom: number | null,
  recentSeconds: number,
  baselineSeconds: number,
): FomoMint[] {
  const recent = countWindow(events, recentFrom, recentTo);
  const baseline = countWindow(events, baselineFrom, baselineTo);
  const six = sixFrom === null ? null : countWindow(events, sixFrom, baselineTo);
  const mints = new Set([...recent.keys(), ...baseline.keys(), ...(six ? six.keys() : [])]);
  const rows: FomoMint[] = [];
  for (const mint of mints) {
    const recentRow = recent.get(mint);
    const baselineRow = baseline.get(mint);
    const sixRow = six?.get(mint);
    rows.push({
      mint,
      symbol: null,
      name: null,
      m15: { trades: recentRow?.trades.size ?? 0, buyers: recentRow?.buyers.size ?? 0 },
      h1: { trades: baselineRow?.trades.size ?? 0, buyers: baselineRow?.buyers.size ?? 0 },
      h6: sixRow ? { trades: sixRow.trades.size, buyers: sixRow.buyers.size } : null,
      recentSeconds,
      baselineSeconds,
    });
  }
  rows.sort(
    (a, b) =>
      (b.h1?.buyers ?? 0) - (a.h1?.buyers ?? 0) ||
      (b.h1?.trades ?? 0) - (a.h1?.trades ?? 0) ||
      a.mint.localeCompare(b.mint),
  );
  return rows.slice(0, WINDOW_LIMIT);
}

export function fomoMintsFromBuys(
  events: readonly BuyEvent[],
  oldestBlockTime: number | null,
  newestBlockTime: number | null,
  nowSec: number,
  transactions: number,
): FomoRead {
  if (oldestBlockTime === null || newestBlockTime === null || transactions === 0) {
    return {
      mints: [],
      note: "Helius returned no Fomo transactions. Nothing can be scored from an empty page.",
    };
  }
  const span = Math.max(0, newestBlockTime - oldestBlockTime);
  if (oldestBlockTime <= nowSec - HOUR) {
    const six = oldestBlockTime <= nowSec - SIX_HOURS;
    return {
      mints: toMints(
        events,
        nowSec - FIFTEEN_MIN,
        nowSec + 300,
        nowSec - HOUR,
        nowSec + 300,
        six ? nowSec - SIX_HOURS : null,
        FIFTEEN_MIN,
        HOUR,
      ),
      note: six
        ? "Helius history reached back at least 6 hours. Buyer counts use 15 minutes, 1 hour, and 6 hours."
        : "Helius history reached back at least 1 hour. Buyer counts use 15 minutes and 1 hour. The 6-hour count was not covered.",
    };
  }
  if (span < MIN_SAMPLE_SECONDS) {
    return {
      mints: [],
      note: `Helius returned ${transactions} transactions spanning under a minute. That is too short to compare pace, so nothing is scored.`,
    };
  }
  const mid = oldestBlockTime + span / 2;
  const minutes = Math.max(1, Math.round(span / 60));
  return {
    mints: toMints(events, mid, newestBlockTime, oldestBlockTime, newestBlockTime, null, Math.max(1, span / 2), span),
    note: `Helius returned ${transactions} transactions spanning about ${minutes} minutes. Buyer counts are that sample, split into a newer half and the full span. They are not a full 15-minute or 1-hour census.`,
  };
}
