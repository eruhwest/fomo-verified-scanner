import { env } from "../env.server.ts";
import { judgeRoundTrip, parseQuote, quoteUrl, TEN_USDC, USDC_MINT, type QuoteCheck, type QuoteLeg } from "./quotes.ts";
import { judgeRug, type RugCheck } from "./rug.ts";

const REQUEST_MS = 12_000;
const DEFAULT_QUOTE_URL = "https://lite-api.jup.ag/swap/v1/quote";
const RUGCHECK_URL = "https://api.rugcheck.xyz/v1/tokens";

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function quoteBase(): string {
  const custom = env("JUPITER_QUOTE_URL");
  if (!custom) return DEFAULT_QUOTE_URL;
  let url: URL;
  try {
    url = new URL(custom);
  } catch {
    throw new Error("JUPITER_QUOTE_URL is not a usable https URL.");
  }
  if (url.protocol !== "https:") throw new Error("JUPITER_QUOTE_URL is not a usable https URL.");
  return url.toString();
}

async function getJson(url: string): Promise<{ ok: true; body: unknown } | { ok: false; missing: boolean; message: string }> {
  let last = "Request failed.";
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const response = await fetch(url, {
        method: "GET",
        headers: { accept: "application/json" },
        signal: AbortSignal.timeout(REQUEST_MS),
      });
      if (response.status === 400 || response.status === 404) {
        return { ok: false, missing: true, message: `HTTP ${response.status}` };
      }
      if (response.status === 429 || response.status >= 500) {
        last = `HTTP ${response.status}`;
        if (attempt === 0) {
          await wait(800);
          continue;
        }
        return { ok: false, missing: false, message: last };
      }
      if (!response.ok) return { ok: false, missing: true, message: `HTTP ${response.status}` };
      return { ok: true, body: await response.json() };
    } catch {
      last = "Request failed.";
      if (attempt === 0) {
        await wait(800);
        continue;
      }
    }
  }
  return { ok: false, missing: false, message: last };
}

async function quoteLeg(inputMint: string, outputMint: string, amount: bigint): Promise<QuoteLeg | null> {
  const result = await getJson(quoteUrl(quoteBase(), inputMint, outputMint, amount));
  if (!result.ok) {
    if (result.missing) return null;
    throw new Error(result.message);
  }
  return parseQuote(result.body);
}

export async function checkRoundTrip(mint: string): Promise<QuoteCheck> {
  const buy = await quoteLeg(USDC_MINT, mint, TEN_USDC);
  if (!buy) return { status: "hide", reason: "sell", sellReturnPct: null };
  await wait(400);
  const sell = await quoteLeg(mint, USDC_MINT, buy.outAmount);
  if (!sell) return { status: "hide", reason: "sell", sellReturnPct: null };
  return judgeRoundTrip(TEN_USDC, buy, sell);
}

export async function checkRug(mint: string): Promise<RugCheck> {
  const result = await getJson(`${RUGCHECK_URL}/${mint}/report`);
  if (!result.ok) {
    if (result.missing) return { status: "hide", reason: "unavailable", score: null };
    throw new Error(result.message);
  }
  return judgeRug(result.body);
}

export async function checkMarketGates(mints: readonly string[]): Promise<{
  quotes: Map<string, QuoteCheck>;
  rugs: Map<string, RugCheck>;
  errors: { source: "jupiter" | "rugcheck"; message: string }[];
}> {
  const quotes = new Map<string, QuoteCheck>();
  const rugs = new Map<string, RugCheck>();
  const errors: { source: "jupiter" | "rugcheck"; message: string }[] = [];
  for (const mint of mints) {
    try {
      quotes.set(mint, await checkRoundTrip(mint));
    } catch (error) {
      errors.push({
        source: "jupiter",
        message: error instanceof Error && error.message ? error.message : "Jupiter quote failed.",
      });
      break;
    }
    await wait(250);
    try {
      rugs.set(mint, await checkRug(mint));
    } catch (error) {
      errors.push({
        source: "rugcheck",
        message: error instanceof Error && error.message ? error.message : "RugCheck request failed.",
      });
      break;
    }
    await wait(200);
  }
  return { quotes, rugs, errors };
}
