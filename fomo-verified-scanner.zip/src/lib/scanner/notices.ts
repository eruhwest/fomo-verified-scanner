import { checkMint } from "../solana-address.ts";

export const ANNOUNCED_STORAGE_KEY = "fomo-verified-scanner.announced.v1";

export function readAnnounced(storage: Pick<Storage, "getItem">): Set<string> {
  try {
    const raw = storage.getItem(ANNOUNCED_STORAGE_KEY);
    if (!raw) return new Set();
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return new Set();
    const mints: string[] = [];
    for (const value of parsed) {
      if (typeof value !== "string") continue;
      const checked = checkMint(value);
      if (checked.ok) mints.push(checked.mint);
    }
    return new Set(mints);
  } catch {
    return new Set();
  }
}

export function writeAnnounced(storage: Pick<Storage, "setItem">, seen: ReadonlySet<string>): void {
  storage.setItem(ANNOUNCED_STORAGE_KEY, JSON.stringify([...seen]));
}

/** Tokens in this feed that have not been announced. Mints that left the feed are forgotten. */
export function takeFreshMatches<T extends { mint: string }>(seen: Set<string>, tokens: readonly T[]): T[] {
  const current = new Set(tokens.map((token) => token.mint));
  for (const mint of seen) {
    if (!current.has(mint)) seen.delete(mint);
  }
  const fresh = tokens.filter((token) => !seen.has(token.mint));
  for (const token of tokens) seen.add(token.mint);
  return fresh;
}
