import { checkMint } from "../solana-address.ts";
import { CHAIN_BATCH } from "./config.ts";

/** Incinerator burn address. Tokens it holds are left out of the holder count. */
const BURN_OWNERS = new Set(["1nc1nerator11111111111111111111111111111111"]);

/**
 * Locker programs. A holder is excluded only when the owner account's program is one of these.
 * Streamflow docs, Streamflow SDK, and the Jupiter Lock program address.
 */
const LOCKER_PROGRAMS = new Set([
  "strmRqUCoQUgGUan5YhzUZa6KqdzwX5L6FpUxfmKg5m",
  "aSTRM2NKoKxNnkmLWk9sz3k74gKBk9t7bpPrTGxMszH",
  "LocpQgucEQHbqNABEYvBvwoxCPsSbG91A1QaQhQQqjn",
]);

const HOLDER_BPS = 300n;
const TOP10_BPS = 2500n;
const POOL_TOLERANCE = 0.02;

export type MintInfo = {
  supply: bigint;
  mintAuthority: string | null;
  freezeAuthority: string | null;
};

export type LargestAccount = {
  address: string;
  amount: bigint;
  uiAmount: number;
};

export type ChainCheck = {
  status: "pass" | "hide";
  reason: "pass" | "mint" | "freeze" | "holder" | "top10" | "unavailable";
  largestHolderPct: number | null;
  top10Pct: number | null;
};

type FomoOrder = {
  mint: string;
  m15: { buyers: number } | null;
  h1: { buyers: number } | null;
};

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function pubkey(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const checked = checkMint(value);
  return checked.ok ? checked.mint : null;
}

function rawAmount(value: unknown): bigint | null {
  if (typeof value !== "string" || !/^\d+$/.test(value)) return null;
  try {
    return BigInt(value);
  } catch {
    return null;
  }
}

function above(amount: bigint, supply: bigint, bps: bigint): boolean {
  return amount * 10000n > supply * bps;
}

function fraction(amount: bigint, supply: bigint): number {
  if (supply <= 0n) return 0;
  return Number((amount * 1_000_000n) / supply) / 1_000_000;
}

export function parseMintInfo(account: unknown): MintInfo | null {
  const record = asRecord(account);
  const data = asRecord(record?.data);
  const parsed = asRecord(data?.parsed);
  const info = asRecord(parsed?.info);
  if (!info || parsed?.type !== "mint") return null;
  const supply = rawAmount(info.supply);
  if (supply === null) return null;
  const mintAuthority = info.mintAuthority === null ? null : pubkey(info.mintAuthority);
  const freezeAuthority = info.freezeAuthority === null ? null : pubkey(info.freezeAuthority);
  if (info.mintAuthority !== null && mintAuthority === null) return null;
  if (info.freezeAuthority !== null && freezeAuthority === null) return null;
  return { supply, mintAuthority, freezeAuthority };
}

export function parseLargestAccounts(value: unknown): LargestAccount[] | null {
  if (!Array.isArray(value) || value.length === 0) return null;
  const accounts: LargestAccount[] = [];
  for (const row of value.slice(0, 20)) {
    const record = asRecord(row);
    if (!record) return null;
    const address = pubkey(record.address);
    const amount = rawAmount(record.amount);
    const uiRaw = typeof record.uiAmountString === "string" ? Number(record.uiAmountString) : Number.NaN;
    if (!address || amount === null || !Number.isFinite(uiRaw) || uiRaw < 0) return null;
    accounts.push({ address, amount, uiAmount: uiRaw });
  }
  return accounts;
}

export function parseTokenOwners(addresses: readonly string[], value: unknown): Map<string, string> | null {
  if (!Array.isArray(value) || value.length !== addresses.length) return null;
  const owners = new Map<string, string>();
  for (let index = 0; index < addresses.length; index += 1) {
    const account = asRecord(value[index]);
    const data = asRecord(account?.data);
    const parsed = asRecord(data?.parsed);
    const info = asRecord(parsed?.info);
    const owner = info ? pubkey(info.owner) : null;
    const address = addresses[index];
    if (!address || parsed?.type !== "account" || !owner) return null;
    owners.set(address, owner);
  }
  return owners;
}

export function parseOwnerPrograms(addresses: readonly string[], value: unknown): Map<string, string | null> | null {
  if (!Array.isArray(value) || value.length !== addresses.length) return null;
  const programs = new Map<string, string | null>();
  for (let index = 0; index < addresses.length; index += 1) {
    const address = addresses[index];
    if (!address) return null;
    const account = value[index];
    if (account === null) {
      programs.set(address, null);
      continue;
    }
    const record = asRecord(account);
    const owner = record ? pubkey(record.owner) : null;
    if (!owner) return null;
    programs.set(address, owner);
  }
  return programs;
}

export function judgeChain(input: {
  mint: MintInfo | null;
  largest: LargestAccount[] | null;
  owners: Map<string, string> | null;
  programs: Map<string, string | null> | null;
  poolBase: number | null;
}): ChainCheck {
  const hide = (reason: ChainCheck["reason"]): ChainCheck => ({
    status: "hide",
    reason,
    largestHolderPct: null,
    top10Pct: null,
  });
  if (!input.mint || input.mint.supply <= 0n) return hide("unavailable");
  if (input.mint.mintAuthority !== null) return hide("mint");
  if (input.mint.freezeAuthority !== null) return hide("freeze");
  if (!input.largest || !input.owners || !input.programs) return hide("unavailable");
  if (input.poolBase === null || !Number.isFinite(input.poolBase) || input.poolBase <= 0) return hide("unavailable");

  let closest = -1;
  let closestDiff = Number.POSITIVE_INFINITY;
  let smallest = Number.POSITIVE_INFINITY;
  for (let index = 0; index < input.largest.length; index += 1) {
    const account = input.largest[index];
    if (!account || !input.owners.has(account.address)) return hide("unavailable");
    const diff = Math.abs(account.uiAmount - input.poolBase) / input.poolBase;
    if (diff < closestDiff) {
      closestDiff = diff;
      closest = index;
    }
    if (account.uiAmount < smallest) smallest = account.uiAmount;
  }

  const exclude = new Set<string>();
  if (closest >= 0 && closestDiff <= POOL_TOLERANCE) {
    const pool = input.largest[closest];
    if (pool) exclude.add(pool.address);
  } else if (!(smallest > input.poolBase * (1 + POOL_TOLERANCE))) {
    return hide("unavailable");
  }

  const totals = new Map<string, bigint>();
  for (const account of input.largest) {
    if (exclude.has(account.address)) continue;
    const owner = input.owners.get(account.address);
    if (!owner) return hide("unavailable");
    if (BURN_OWNERS.has(owner)) continue;
    const program = input.programs.get(owner);
    if (program === undefined) return hide("unavailable");
    if (program !== null && (LOCKER_PROGRAMS.has(program) || LOCKER_PROGRAMS.has(owner))) continue;
    totals.set(owner, (totals.get(owner) ?? 0n) + account.amount);
  }

  if (totals.size === 0 && input.largest.length >= 20) return hide("unavailable");

  const ranked = [...totals.values()].sort((a, b) => (a > b ? -1 : a < b ? 1 : 0));
  const largest = ranked[0] ?? 0n;
  let top10 = 0n;
  for (const amount of ranked.slice(0, 10)) top10 += amount;
  const largestHolderPct = fraction(largest, input.mint.supply);
  const top10Pct = fraction(top10, input.mint.supply);
  if (above(largest, input.mint.supply, HOLDER_BPS)) {
    return { status: "hide", reason: "holder", largestHolderPct, top10Pct };
  }
  if (above(top10, input.mint.supply, TOP10_BPS)) {
    return { status: "hide", reason: "top10", largestHolderPct, top10Pct };
  }
  return { status: "pass", reason: "pass", largestHolderPct, top10Pct };
}

export function selectChainMints(
  pasted: readonly string[],
  fomo: readonly FomoOrder[],
  paired: ReadonlySet<string>,
  limit = CHAIN_BATCH,
): { selected: string[]; skipped: number } {
  const selected: string[] = [];
  const seen = new Set<string>();
  const consider = (mint: string) => {
    if (seen.has(mint) || !paired.has(mint)) return;
    seen.add(mint);
    if (selected.length < limit) selected.push(mint);
  };
  for (const mint of pasted) consider(mint);
  const ordered = [...fomo].sort(
    (a, b) => (b.h1?.buyers ?? b.m15?.buyers ?? 0) - (a.h1?.buyers ?? a.m15?.buyers ?? 0),
  );
  for (const item of ordered) consider(item.mint);
  return { selected, skipped: seen.size - selected.length };
}
