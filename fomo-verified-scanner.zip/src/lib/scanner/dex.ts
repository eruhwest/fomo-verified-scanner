import { DEX_TOKEN_URL } from "./config.ts";
import { checkMint } from "../solana-address.ts";
import type { MarketPair, SocialLink } from "./types.ts";

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function finiteNumber(value: unknown): number | null {
  if (typeof value !== "number" || !Number.isFinite(value)) return null;
  return value;
}

function price(value: unknown): number | null {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value !== "string" || !value.trim()) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function text(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function httpsUrl(value: unknown): string | null {
  if (typeof value !== "string") return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:") return null;
    return url.toString();
  } catch {
    return null;
  }
}

function socialsOf(info: Record<string, unknown> | null): SocialLink[] {
  if (!info) return [];
  const links: SocialLink[] = [];
  const push = (label: string, url: string | null) => {
    if (!url || links.some((item) => item.url === url) || links.length >= 6) return;
    links.push({ label, url });
  };
  if (Array.isArray(info.socials)) {
    for (const item of info.socials) {
      const record = asRecord(item);
      if (!record) continue;
      const label = text(record.type) ?? text(record.platform) ?? text(record.label) ?? "Link";
      push(label, httpsUrl(record.url));
    }
  }
  if (Array.isArray(info.websites)) {
    for (const item of info.websites) {
      const record = asRecord(item);
      if (!record) continue;
      push(text(record.label) ?? "Website", httpsUrl(record.url));
    }
  }
  return links;
}

function pairFor(mint: string, row: unknown): MarketPair | null {
  const record = asRecord(row);
  if (!record) return null;
  const base = asRecord(record.baseToken);
  const address = text(base?.address);
  const checked = address ? checkMint(address) : null;
  if (!checked?.ok || checked.mint !== mint) return null;
  const liquidity = asRecord(record.liquidity);
  const liquidityUsd = finiteNumber(liquidity?.usd);
  if (liquidityUsd === null || liquidityUsd < 0) return null;
  const poolBaseRaw = finiteNumber(liquidity?.base);
  const poolBase = poolBaseRaw !== null && poolBaseRaw > 0 ? poolBaseRaw : null;
  const volume = asRecord(record.volume);
  const change = asRecord(record.priceChange);
  const txns = asRecord(asRecord(record.txns)?.m5);
  const fromApi = httpsUrl(record.url);
  const pairUrl =
    fromApi && fromApi.startsWith("https://dexscreener.com/")
      ? fromApi
      : `https://dexscreener.com/solana/${mint}`;
  return {
    mint,
    name: text(base?.name),
    symbol: text(base?.symbol),
    pairUrl,
    priceUsd: price(record.priceUsd),
    liquidityUsd,
    marketCapUsd: finiteNumber(record.marketCap),
    volumeM5Usd: finiteNumber(volume?.m5),
    volumeH1Usd: finiteNumber(volume?.h1),
    priceChangeH1: finiteNumber(change?.h1),
    buysM5: finiteNumber(txns?.buys),
    sellsM5: finiteNumber(txns?.sells),
    pairCreatedAt: finiteNumber(record.pairCreatedAt),
    socials: socialsOf(asRecord(record.info)),
    poolBase,
  };
}

/** Highest USD liquidity among pairs whose base token is this mint. */
export function selectMainPair(mint: string, payload: unknown): MarketPair | null {
  if (!Array.isArray(payload)) {
    throw new Error("DexScreener response was not a list.");
  }
  let best: MarketPair | null = null;
  for (const row of payload) {
    const pair = pairFor(mint, row);
    if (!pair) continue;
    if (!best || pair.liquidityUsd > best.liquidityUsd) best = pair;
  }
  return best;
}

export function dexUrl(mints: readonly string[]): string {
  return `${DEX_TOKEN_URL}/${mints.join(",")}`;
}
