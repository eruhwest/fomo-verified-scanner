import { env } from "../env.server.ts";
import {
  judgeChain,
  parseLargestAccounts,
  parseMintInfo,
  parseOwnerPrograms,
  parseTokenOwners,
  type ChainCheck,
} from "./chain.ts";
import { PUBLIC_SOLANA_RPC } from "./config.ts";

const REQUEST_MS = 12_000;
const PUBLIC_FALLBACKS = [PUBLIC_SOLANA_RPC, "https://api.mainnet-beta.solana.com"];

function endpoints(): string[] {
  const custom = env("SOLANA_RPC_URL");
  if (!custom) return PUBLIC_FALLBACKS;
  let url: URL;
  try {
    url = new URL(custom);
  } catch {
    throw new Error("SOLANA_RPC_URL is not a usable https URL.");
  }
  if (url.protocol !== "https:") throw new Error("SOLANA_RPC_URL is not a usable https URL.");
  return [url.toString()];
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function postRpc(body: unknown): Promise<unknown> {
  const urls = endpoints();
  let last = "Solana RPC request failed.";
  for (let round = 0; round < 2; round += 1) {
    for (const url of urls) {
      try {
        const response = await fetch(url, {
          method: "POST",
          headers: { accept: "application/json", "content-type": "application/json" },
          body: JSON.stringify(body),
          signal: AbortSignal.timeout(REQUEST_MS),
        });
        if (response.status === 429 || response.status === 403 || response.status >= 500) {
          last = `HTTP ${response.status}`;
          continue;
        }
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.json();
      } catch (error) {
        last = error instanceof Error && /^HTTP \d+$/.test(error.message) ? error.message : "Solana RPC request failed.";
      }
    }
    if (round === 0) await wait(800);
  }
  throw new Error(last);
}

function rpcResult(payload: unknown): unknown | null {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) return null;
  const record = payload as { result?: unknown; error?: unknown };
  if (record.error) return null;
  return "result" in record ? record.result : null;
}

async function rpcValue(method: string, params: unknown[]): Promise<unknown | null> {
  const payload = await postRpc({ jsonrpc: "2.0", id: 1, method, params });
  const result = rpcResult(payload);
  if (!result || typeof result !== "object") return null;
  return (result as { value?: unknown }).value ?? null;
}

async function accountsFor(addresses: readonly string[]): Promise<unknown[] | null> {
  if (addresses.length === 0) return [];
  const payload = await postRpc({
    jsonrpc: "2.0",
    id: 1,
    method: "getMultipleAccounts",
    params: [addresses, { encoding: "jsonParsed", commitment: "confirmed" }],
  });
  const result = rpcResult(payload);
  if (!result || typeof result !== "object") return null;
  const value = (result as { value?: unknown }).value;
  return Array.isArray(value) ? value : null;
}

async function checkOne(mint: string, poolBase: number | null): Promise<ChainCheck> {
  const unavailable: ChainCheck = {
    status: "hide",
    reason: "unavailable",
    largestHolderPct: null,
    top10Pct: null,
  };
  if (poolBase === null) return unavailable;
  const mintAccount = await rpcValue("getAccountInfo", [mint, { encoding: "jsonParsed", commitment: "confirmed" }]);
  await wait(200);
  const largestValue = await rpcValue("getTokenLargestAccounts", [mint, { commitment: "confirmed" }]);
  const mintInfo = parseMintInfo(mintAccount);
  const largest = parseLargestAccounts(largestValue);
  if (!mintInfo || !largest) {
    return judgeChain({ mint: mintInfo, largest, owners: null, programs: null, poolBase });
  }
  if (mintInfo.mintAuthority !== null || mintInfo.freezeAuthority !== null) {
    return judgeChain({ mint: mintInfo, largest: null, owners: null, programs: null, poolBase });
  }
  await wait(200);
  const tokenAccounts = await accountsFor(largest.map((account) => account.address));
  const owners = tokenAccounts ? parseTokenOwners(largest.map((account) => account.address), tokenAccounts) : null;
  if (!owners) return unavailable;
  const uniqueOwners = [...new Set(owners.values())];
  await wait(200);
  const ownerAccounts = await accountsFor(uniqueOwners);
  const programs = ownerAccounts ? parseOwnerPrograms(uniqueOwners, ownerAccounts) : null;
  return judgeChain({ mint: mintInfo, largest, owners, programs, poolBase });
}

export async function checkMintsOnChain(
  items: readonly { mint: string; poolBase: number | null }[],
): Promise<{ verdicts: Map<string, ChainCheck>; error: string | null }> {
  const verdicts = new Map<string, ChainCheck>();
  let error: string | null = null;
  for (const item of items) {
    try {
      verdicts.set(item.mint, await checkOne(item.mint, item.poolBase));
    } catch (caught) {
      error = caught instanceof Error && caught.message ? caught.message : "Solana RPC request failed.";
      break;
    }
    await wait(250);
  }
  return { verdicts, error };
}
