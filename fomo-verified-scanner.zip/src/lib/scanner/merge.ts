import type { ChainCheck } from "./chain.ts";
import { MIN_LIQUIDITY_USD } from "./config.ts";
import { scoreMomentum } from "./momentum.ts";
import type { QuoteCheck } from "./quotes.ts";
import type { RugCheck } from "./rug.ts";
import type { DiscoveredToken, FomoMint, MarketPair } from "./types.ts";

export function mergeDiscovered(
  fomo: readonly FomoMint[],
  pairs: ReadonlyMap<string, MarketPair | null>,
  pasted: readonly string[],
  chains: ReadonlyMap<string, ChainCheck>,
  quotes: ReadonlyMap<string, QuoteCheck>,
  rugs: ReadonlyMap<string, RugCheck>,
): { discovered: DiscoveredToken[]; hidden: number; scanned: number } {
  const fomoByMint = new Map(fomo.map((item) => [item.mint, item]));
  const mints: string[] = [];
  const seen = new Set<string>();
  for (const item of fomo) {
    if (seen.has(item.mint)) continue;
    seen.add(item.mint);
    mints.push(item.mint);
  }
  for (const mint of pasted) {
    if (seen.has(mint)) continue;
    seen.add(mint);
    mints.push(mint);
  }

  const discovered: DiscoveredToken[] = [];
  let hidden = 0;
  for (const mint of mints) {
    const pair = pairs.get(mint);
    const chain = chains.get(mint);
    const quote = quotes.get(mint);
    const rug = rugs.get(mint);
    if (
      !pair ||
      pair.liquidityUsd < MIN_LIQUIDITY_USD ||
      chain?.status !== "pass" ||
      chain.largestHolderPct === null ||
      chain.top10Pct === null ||
      quote?.status !== "pass" ||
      quote.sellReturnPct === null ||
      rug?.status !== "pass" ||
      rug.score === null
    ) {
      hidden += 1;
      continue;
    }
    const fromFomo = fomoByMint.get(mint) ?? null;
    if (pair.volumeH1Usd === null || pair.priceChangeH1 === null) {
      hidden += 1;
      continue;
    }
    const momentum = scoreMomentum({
      buyers15: fromFomo?.m15?.buyers ?? null,
      buyers60: fromFomo?.h1?.buyers ?? null,
      trades15: fromFomo?.m15?.trades ?? null,
      trades60: fromFomo?.h1?.trades ?? null,
      volumeM5Usd: pair.volumeM5Usd,
      volumeH1Usd: pair.volumeH1Usd,
      buysM5: pair.buysM5,
      sellsM5: pair.sellsM5,
      priceChangeH1: pair.priceChangeH1,
      recentSeconds: fromFomo?.recentSeconds,
      baselineSeconds: fromFomo?.baselineSeconds,
    });
    if (!momentum) {
      hidden += 1;
      continue;
    }
    const fromList = pasted.includes(mint);
    discovered.push({
      mint,
      name: pair.name ?? fromFomo?.name ?? null,
      symbol: pair.symbol ?? fromFomo?.symbol ?? null,
      source: fromFomo && fromList ? "both" : fromFomo ? "fomo" : "list",
      pairUrl: pair.pairUrl,
      priceUsd: pair.priceUsd,
      liquidityUsd: pair.liquidityUsd,
      marketCapUsd: pair.marketCapUsd,
      volumeM5Usd: pair.volumeM5Usd,
      volumeH1Usd: pair.volumeH1Usd,
      priceChangeH1: pair.priceChangeH1,
      buysM5: pair.buysM5,
      sellsM5: pair.sellsM5,
      pairCreatedAt: pair.pairCreatedAt,
      fomo: {
        m15: fromFomo?.m15 ?? null,
        h1: fromFomo?.h1 ?? null,
        h6: fromFomo?.h6 ?? null,
      },
      socials: pair.socials,
      largestHolderPct: chain.largestHolderPct,
      top10Pct: chain.top10Pct,
      sellReturnPct: quote.sellReturnPct,
      rugScore: rug.score,
      momentumScore: momentum.score,
      lateChaser: momentum.lateChaser,
      buyerRise: momentum.buyerRise,
      volumeRise: momentum.volumeRise,
      recentSeconds: fromFomo?.recentSeconds ?? 900,
      baselineSeconds: fromFomo?.baselineSeconds ?? 3600,
    });
  }

  discovered.sort((a, b) => b.momentumScore - a.momentumScore || a.mint.localeCompare(b.mint));

  return { discovered, hidden, scanned: mints.length };
}
