import { createServerFn } from "@tanstack/react-start";
import { checkMint } from "../solana-address.ts";

const MAX_MINTS = 100;

export const getMarketScan = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object") throw new Error("Invalid scan request.");
    const mints = (input as { mints?: unknown }).mints;
    if (!Array.isArray(mints) || mints.length > MAX_MINTS) throw new Error("Invalid mint list.");
    const clean: string[] = [];
    const seen = new Set<string>();
    for (const mint of mints) {
      if (typeof mint !== "string") throw new Error("Invalid mint.");
      const checked = checkMint(mint);
      if (!checked.ok) throw new Error("Invalid mint.");
      if (seen.has(checked.mint)) continue;
      seen.add(checked.mint);
      clean.push(checked.mint);
    }
    return { mints: clean };
  })
  .handler(async ({ data }) => {
    const { publicScan } = await import("./discover.server.ts");
    return publicScan(data.mints);
  });
