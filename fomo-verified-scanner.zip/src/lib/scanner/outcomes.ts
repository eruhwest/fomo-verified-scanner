import { checkMint } from "../solana-address.ts";

const HOUR = 60 * 60 * 1000;

export const OUTCOME_MARKS = {
  h1: HOUR,
  h6: 6 * HOUR,
  h24: 24 * HOUR,
} as const;

const LAST_MARK = 48 * HOUR;
const TRACK_LIMIT = 100;

export type OutcomeCheckpoint = {
  priceUsd: number;
  at: number;
};

export type OutcomeRecord = {
  mint: string;
  symbol: string | null;
  name: string | null;
  seenAt: number;
  entryPriceUsd: number;
  h1: OutcomeCheckpoint | null;
  h6: OutcomeCheckpoint | null;
  h24: OutcomeCheckpoint | null;
};

export type RankedSighting = {
  mint: string;
  symbol: string | null;
  name: string | null;
  priceUsd: number | null;
};

export type OutcomeCell =
  | { state: "pending" }
  | { state: "waiting" }
  | { state: "missing" }
  | { state: "set"; priceUsd: number; changePct: number; at: string };

export type OutcomeRow = {
  mint: string;
  symbol: string | null;
  name: string | null;
  seenAt: string;
  entryPriceUsd: number;
  h1: OutcomeCell;
  h6: OutcomeCell;
  h24: OutcomeCell;
};

type Mark = keyof typeof OUTCOME_MARKS;

const MARKS: Mark[] = ["h1", "h6", "h24"];

function usablePrice(value: number | null | undefined): value is number {
  return typeof value === "number" && Number.isFinite(value) && value > 0;
}

function text(value: string | null): string | null {
  if (!value) return null;
  const trimmed = value.trim();
  return trimmed ? trimmed.slice(0, 40) : null;
}

function windowFor(mark: Mark): { start: number; end: number } {
  if (mark === "h1") return { start: OUTCOME_MARKS.h1, end: OUTCOME_MARKS.h6 };
  if (mark === "h6") return { start: OUTCOME_MARKS.h6, end: OUTCOME_MARKS.h24 };
  return { start: OUTCOME_MARKS.h24, end: LAST_MARK };
}

export function needsOutcomePrice(record: OutcomeRecord, now: number): boolean {
  const age = now - record.seenAt;
  if (age < OUTCOME_MARKS.h1 || age >= LAST_MARK) return false;
  return MARKS.some((mark) => {
    if (record[mark]) return false;
    const span = windowFor(mark);
    return age >= span.start && age < span.end;
  });
}

function fillRecord(
  record: OutcomeRecord,
  price: number | null,
  now: number,
): OutcomeRecord {
  if (!usablePrice(price)) return record;
  let next = record;
  const age = now - record.seenAt;
  for (const mark of MARKS) {
    if (next[mark]) continue;
    const span = windowFor(mark);
    if (age < span.start || age >= span.end) continue;
    next = { ...next, [mark]: { priceUsd: price, at: now } };
  }
  return next;
}

export function applyOutcomes(
  existing: readonly OutcomeRecord[],
  ranked: readonly RankedSighting[],
  prices: ReadonlyMap<string, number | null>,
  now: number,
): OutcomeRecord[] {
  const byMint = new Map<string, OutcomeRecord>();
  for (const record of existing) {
    const checked = checkMint(record.mint);
    if (!checked.ok || byMint.has(checked.mint) || !usablePrice(record.entryPriceUsd)) continue;
    byMint.set(checked.mint, { ...record, mint: checked.mint });
  }

  for (const sight of ranked) {
    const checked = checkMint(sight.mint);
    if (!checked.ok || !usablePrice(sight.priceUsd)) continue;
    const prior = byMint.get(checked.mint);
    if (!prior) {
      byMint.set(checked.mint, {
        mint: checked.mint,
        symbol: text(sight.symbol),
        name: text(sight.name),
        seenAt: now,
        entryPriceUsd: sight.priceUsd,
        h1: null,
        h6: null,
        h24: null,
      });
      continue;
    }
    if (!prior.symbol && sight.symbol) prior.symbol = text(sight.symbol);
    if (!prior.name && sight.name) prior.name = text(sight.name);
  }

  const next: OutcomeRecord[] = [];
  for (const record of byMint.values()) {
    const price = prices.has(record.mint) ? (prices.get(record.mint) ?? null) : null;
    const filled = fillRecord(record, usablePrice(price) ? price : null, now);
    const age = now - filled.seenAt;
    const finished = age >= LAST_MARK;
    if (finished && age > 7 * 24 * HOUR) continue;
    next.push(filled);
  }

  next.sort((a, b) => b.seenAt - a.seenAt || a.mint.localeCompare(b.mint));
  return next.slice(0, TRACK_LIMIT);
}

function cell(record: OutcomeRecord, mark: Mark, now: number): OutcomeCell {
  const point = record[mark];
  if (point && usablePrice(point.priceUsd)) {
    return {
      state: "set",
      priceUsd: point.priceUsd,
      changePct: (point.priceUsd - record.entryPriceUsd) / record.entryPriceUsd,
      at: new Date(point.at).toISOString(),
    };
  }
  const age = now - record.seenAt;
  const span = windowFor(mark);
  if (age < span.start) return { state: "pending" };
  if (age < span.end) return { state: "waiting" };
  return { state: "missing" };
}

export function toOutcomeRows(records: readonly OutcomeRecord[], now: number): OutcomeRow[] {
  return records.slice(0, 20).map((record) => ({
    mint: record.mint,
    symbol: record.symbol,
    name: record.name,
    seenAt: new Date(record.seenAt).toISOString(),
    entryPriceUsd: record.entryPriceUsd,
    h1: cell(record, "h1", now),
    h6: cell(record, "h6", now),
    h24: cell(record, "h24", now),
  }));
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function parseCheckpoint(value: unknown): OutcomeCheckpoint | null | undefined {
  if (value === null || value === undefined) return null;
  const record = asRecord(value);
  if (!record || !usablePrice(record.priceUsd as number) || typeof record.at !== "number") return undefined;
  return { priceUsd: record.priceUsd as number, at: record.at };
}

export function parseOutcomeFile(payload: unknown): OutcomeRecord[] {
  if (!Array.isArray(payload)) return [];
  const records: OutcomeRecord[] = [];
  for (const item of payload) {
    const record = asRecord(item);
    if (!record) continue;
    const checked = typeof record.mint === "string" ? checkMint(record.mint) : null;
    if (!checked?.ok || typeof record.seenAt !== "number" || !usablePrice(record.entryPriceUsd as number)) continue;
    const h1 = parseCheckpoint(record.h1);
    const h6 = parseCheckpoint(record.h6);
    const h24 = parseCheckpoint(record.h24);
    if (h1 === undefined || h6 === undefined || h24 === undefined) continue;
    records.push({
      mint: checked.mint,
      symbol: typeof record.symbol === "string" ? text(record.symbol) : null,
      name: typeof record.name === "string" ? text(record.name) : null,
      seenAt: record.seenAt,
      entryPriceUsd: record.entryPriceUsd as number,
      h1,
      h6,
      h24,
    });
  }
  return records;
}
