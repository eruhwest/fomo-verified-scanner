import { env } from "../env.server.ts";
import { checkMintsOnChain } from "./chain.server.ts";
import type { ChainCheck } from "./chain.ts";
import { selectChainMints } from "./chain.ts";
import { FOMO_SIGNER, MIN_LIQUIDITY_USD, scanIntervalMinutes } from "./config.ts";
import { fomoMintsFromBuys, parseHeliusTransactions, type BuyEvent } from "./helius.ts";
import { checkMarketGates } from "./markets.server.ts";
import type { QuoteCheck } from "./quotes.ts";
import type { RugCheck } from "./rug.ts";
import { dexUrl, selectMainPair } from "./dex.ts";
import { mergeDiscovered } from "./merge.ts";
import { syncOutcomes } from "./outcomes.server.ts";
import type { OutcomeRow } from "./outcomes.ts";
import type { FomoMint, MarketPair, ScanSnapshot, ServiceError } from "./types.ts";

const REQUEST_MS = 12_000;
const PASTE_CAP = 100;

type Store = {
  fetchedAt: number;
  stale: boolean;
  bitqueryConfigured: boolean;
  discoveryNote: string | null;
  fomo: FomoMint[];
  fomoMints: number;
  errors: ServiceError[];
  pairs: Map<string, MarketPair | null>;
  chains: Map<string, ChainCheck>;
  quotes: Map<string, QuoteCheck>;
  rugs: Map<string, RugCheck>;
  pasted: string[];
  outcomes: OutcomeRow[];
};

type Slot = {
  store: Store | null;
  timer: ReturnType<typeof setInterval> | null;
  tail: Promise<void>;
};

function slot(): Slot {
  const g = globalThis as typeof globalThis & { __fomoScanSlot?: Slot };
  if (!g.__fomoScanSlot) {
    g.__fomoScanSlot = { store: null, timer: null, tail: Promise.resolve() };
  }
  return g.__fomoScanSlot;
}

function enqueue<T>(work: () => Promise<T>): Promise<T> {
  const state = slot();
  const run = state.tail.then(work, work);
  state.tail = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

function publicMessage(error: unknown, fallback: string): string {
  const raw = error instanceof Error && error.message ? error.message : fallback;
  return raw.replace(/Bearer\s+\S+/gi, "Bearer [redacted]").replace(/api-key=[^&\s]+/gi, "api-key=[redacted]").slice(0, 180);
}

async function fetchJson(url: string, init: RequestInit): Promise<unknown> {
  let last: unknown;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const response = await fetch(url, { ...init, signal: AbortSignal.timeout(REQUEST_MS) });
      if (response.status === 429 || response.status >= 500) {
        last = new Error(`HTTP ${response.status}`);
        if (attempt === 0) {
          await new Promise((resolve) => setTimeout(resolve, 1000));
          continue;
        }
        throw last;
      }
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (error) {
      last = error;
      const retry =
        error instanceof Error &&
        (error.name === "TimeoutError" || error.name === "AbortError" || error.message.startsWith("HTTP 429") || error.message.startsWith("HTTP 5"));
      if (attempt === 0 && retry) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
        continue;
      }
      throw error instanceof Error ? error : new Error("Request failed");
    }
  }
  throw last instanceof Error ? last : new Error("Request failed");
}

const HELIUS_PAGE = 1000;
const HELIUS_PAGES = 1;

async function fetchFomo(apiKey: string): Promise<{ mints: FomoMint[]; note: string }> {
  const events: BuyEvent[] = [];
  let oldest: number | null = null;
  let newest: number | null = null;
  let transactions = 0;
  let paginationToken: string | null = null;
  for (let page = 0; page < HELIUS_PAGES; page += 1) {
    const payload = await fetchJson(`https://mainnet.helius-rpc.com/?api-key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "getTransactionsForAddress",
        params: [
          FOMO_SIGNER,
          {
            transactionDetails: "full",
            encoding: "jsonParsed",
            sortOrder: "desc",
            limit: HELIUS_PAGE,
            maxSupportedTransactionVersion: 1,
            commitment: "confirmed",
            filters: { status: "succeeded" },
            ...(paginationToken ? { paginationToken } : {}),
          },
        ],
      }),
    });
    const parsed = parseHeliusTransactions(payload);
    events.push(...parsed.events);
    transactions += parsed.transactionCount;
    if (parsed.oldestBlockTime !== null) oldest = oldest === null ? parsed.oldestBlockTime : Math.min(oldest, parsed.oldestBlockTime);
    if (parsed.newestBlockTime !== null) newest = newest === null ? parsed.newestBlockTime : Math.max(newest, parsed.newestBlockTime);
    if (!parsed.paginationToken || parsed.transactionCount < HELIUS_PAGE) break;
    paginationToken = parsed.paginationToken;
  }
  return {
    ...fomoMintsFromBuys(events, oldest, newest, Math.floor(Date.now() / 1000), transactions),
  };
}

async function fetchPairs(mints: readonly string[]): Promise<{
  pairs: Map<string, MarketPair | null>;
  failed: string[];
  errors: ServiceError[];
}> {
  const pairs = new Map<string, MarketPair | null>();
  const failed: string[] = [];
  const errors: ServiceError[] = [];
  for (let index = 0; index < mints.length; index += 30) {
    const batch = mints.slice(index, index + 30);
    try {
      const payload = await fetchJson(dexUrl(batch), {
        method: "GET",
        headers: { accept: "application/json" },
      });
      for (const mint of batch) pairs.set(mint, selectMainPair(mint, payload));
    } catch (error) {
      errors.push({
        source: "dexscreener",
        message: publicMessage(error, "DexScreener request failed."),
      });
      failed.push(...batch);
      for (const mint of batch) pairs.set(mint, null);
    }
  }
  return { pairs, failed, errors };
}

async function fetchChains(
  pasted: readonly string[],
  fomo: readonly FomoMint[],
  pairs: ReadonlyMap<string, MarketPair | null>,
): Promise<{ chains: Map<string, ChainCheck>; errors: ServiceError[] }> {
  const paired = new Set<string>();
  for (const [mint, pair] of pairs) {
    if (pair && pair.liquidityUsd >= MIN_LIQUIDITY_USD) paired.add(mint);
  }
  const queue = selectChainMints(pasted, fomo, paired);
  const items = queue.selected.map((mint) => ({
    mint,
    poolBase: pairs.get(mint)?.poolBase ?? null,
  }));
  const errors: ServiceError[] = [];
  if (queue.skipped > 0) {
    errors.push({
      source: "solana",
      message: `On-chain checks ran for ${queue.selected.length} tokens with a pool. ${queue.skipped} more stayed hidden.`,
    });
  }
  try {
    const result = await checkMintsOnChain(items);
    if (result.error) {
      errors.push({ source: "solana", message: result.error });
    }
    return { chains: result.verdicts, errors };
  } catch (error) {
    errors.push({
      source: "solana",
      message: error instanceof Error && error.message ? error.message : "Solana RPC request failed.",
    });
    return { chains: new Map(), errors };
  }
}

function intervalMs(): number {
  return scanIntervalMinutes(env("SCAN_INTERVAL_MINUTES")) * 60_000;
}

function emptyStore(configured: boolean): Store {
  return {
    fetchedAt: 0,
    stale: false,
    bitqueryConfigured: configured,
    discoveryNote: null,
    fomo: [],
    fomoMints: 0,
    errors: [],
    pairs: new Map(),
    chains: new Map(),
    quotes: new Map(),
    rugs: new Map(),
    pasted: [],
    outcomes: [],
  };
}

async function refresh(pasted: readonly string[]): Promise<Store> {
  const token = env("HELIUS_API_KEY");
  const previous = slot().store;
  const errors: ServiceError[] = [];
  let fomo: FomoMint[] = [];
  let discoveryNote: string | null = null;
  let stale = false;
  if (!token) {
    errors.push({
      source: "helius",
      message: "HELIUS_API_KEY is not set on the server. Automatic Fomo discovery did not run.",
    });
  } else {
    try {
      const read = await fetchFomo(token);
      fomo = read.mints;
      discoveryNote = read.note;
    } catch (error) {
      errors.push({
        source: "helius",
        message: publicMessage(error, "Helius request failed."),
      });
      if (previous && previous.fomo.length > 0 && !previous.errors.some((item) => item.source === "helius")) {
        fomo = previous.fomo;
        discoveryNote = previous.discoveryNote;
        stale = true;
      }
    }
  }

  const wanted = new Set<string>(pasted);
  for (const item of fomo) wanted.add(item.mint);
  const { pairs, failed, errors: dexErrors } = await fetchPairs([...wanted]);
  errors.push(...dexErrors);
  if (previous) {
    for (const mint of failed) {
      const prior = previous.pairs.get(mint);
      if (prior) {
        pairs.set(mint, prior);
        stale = true;
      }
    }
  }

  const { chains, errors: chainErrors } = await fetchChains(pasted, fomo, pairs);
  errors.push(...chainErrors);
  const ready = [...chains.entries()].filter(([, verdict]) => verdict.status === "pass").map(([mint]) => mint);
  const markets = await checkMarketGates(ready);
  errors.push(...markets.errors);

  return {
    fetchedAt: Date.now(),
    stale,
    bitqueryConfigured: Boolean(token),
    discoveryNote,
    fomo,
    fomoMints: fomo.length,
    errors,
    pairs,
    chains,
    quotes: markets.quotes,
    rugs: markets.rugs,
    pasted: [...pasted],
    outcomes: previous?.outcomes ?? [],
  };
}

function toSnapshot(store: Store): ScanSnapshot {
  const merged = mergeDiscovered(
    store.fomo,
    store.pairs,
    store.pasted,
    store.chains ?? new Map(),
    store.quotes ?? new Map(),
    store.rugs ?? new Map(),
  );
  return {
    scannedAt: store.fetchedAt ? new Date(store.fetchedAt).toISOString() : null,
    stale: store.stale,
    intervalMinutes: scanIntervalMinutes(env("SCAN_INTERVAL_MINUTES")),
    bitqueryConfigured: store.bitqueryConfigured,
    discoveryNote: store.discoveryNote,
    tokensScanned: merged.scanned,
    fomoMints: store.fomoMints,
    hiddenByGates: merged.hidden,
    serviceErrors: store.errors,
    discovered: merged.discovered,
    outcomes: store.outcomes ?? [],
  };
}

async function stamp(store: Store): Promise<Store> {
  try {
    const merged = mergeDiscovered(
      store.fomo,
      store.pairs,
      store.pasted,
      store.chains ?? new Map(),
      store.quotes ?? new Map(),
      store.rugs ?? new Map(),
    );
    const result = await syncOutcomes(
      merged.discovered.map((token) => ({
        mint: token.mint,
        symbol: token.symbol,
        name: token.name,
        priceUsd: token.priceUsd,
      })),
    );
    const errors = [...store.errors];
    for (const error of result.errors) {
      if (!errors.some((item) => item.source === error.source && item.message === error.message)) {
        errors.push(error);
      }
    }
    return { ...store, errors, outcomes: result.rows };
  } catch {
    return { ...store, outcomes: store.outcomes ?? [] };
  }
}

function rememberPasted(extra: readonly string[]): string[] {
  const next: string[] = [];
  const seen = new Set<string>();
  for (const mint of extra) {
    if (seen.has(mint)) continue;
    seen.add(mint);
    next.push(mint);
    if (next.length >= PASTE_CAP) break;
  }
  return next;
}

async function ensureFresh(extra: readonly string[]): Promise<Store> {
  const state = slot();
  const pasted = rememberPasted(extra);
  const age = state.store ? Date.now() - state.store.fetchedAt : Number.POSITIVE_INFINITY;
  if (!state.store?.chains || !state.store.quotes || !state.store.rugs || age >= intervalMs()) {
    state.store = await refresh(pasted);
  } else {
    const missing = pasted.filter((mint) => !state.store?.pairs.has(mint));
    if (missing.length > 0) {
      const found = await fetchPairs(missing);
      for (const [mint, pair] of found.pairs) state.store.pairs.set(mint, pair);
      for (const error of found.errors) {
        const already = state.store.errors.some(
          (item) => item.source === error.source && item.message === error.message,
        );
        if (!already) state.store.errors.push(error);
      }
    }
    const unchecked = pasted.filter((mint) => state.store?.pairs.get(mint) && !state.store.chains.has(mint));
    if (unchecked.length > 0) {
      const chain = await fetchChains(unchecked, [], state.store.pairs);
      for (const [mint, verdict] of chain.chains) state.store.chains.set(mint, verdict);
      for (const error of chain.errors) {
        const already = state.store.errors.some(
          (item) => item.source === error.source && item.message === error.message,
        );
        if (!already) state.store.errors.push(error);
      }
      const passed = unchecked.filter((mint) => state.store?.chains.get(mint)?.status === "pass");
      if (passed.length > 0) {
        const markets = await checkMarketGates(passed);
        for (const [mint, verdict] of markets.quotes) state.store.quotes.set(mint, verdict);
        for (const [mint, verdict] of markets.rugs) state.store.rugs.set(mint, verdict);
        for (const error of markets.errors) {
          const already = state.store.errors.some(
            (item) => item.source === error.source && item.message === error.message,
          );
          if (!already) state.store.errors.push(error);
        }
      }
    }
    state.store = { ...state.store, pasted };
  }
  state.store = await stamp(state.store);
  return state.store;
}

export function startScanner(): void {
  const state = slot();
  if (state.timer) return;
  state.timer = setInterval(() => {
    void enqueue(async () => {
      const current = slot();
      current.store = await stamp(await refresh(current.store?.pasted ?? []));
    }).catch(() => undefined);
  }, intervalMs());
  state.timer.unref?.();
}

export function publicScan(extraMints: readonly string[]): Promise<ScanSnapshot> {
  startScanner();
  return enqueue(async () => toSnapshot(await ensureFresh(extraMints)));
}

export function forceScan(): Promise<ScanSnapshot> {
  startScanner();
  return enqueue(async () => {
    const state = slot();
    state.store = await stamp(await refresh(state.store?.pasted ?? []));
    return toSnapshot(state.store);
  });
}
