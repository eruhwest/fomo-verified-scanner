export const USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
export const TEN_USDC = 10_000_000n;
const SELL_FLOOR_BPS = 8000n;

export type QuoteLeg = {
  inAmount: bigint;
  outAmount: bigint;
};

export type QuoteCheck = {
  status: "pass" | "hide";
  reason: "pass" | "sell" | "unavailable";
  sellReturnPct: number | null;
};

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function rawAmount(value: unknown): bigint | null {
  if (typeof value !== "string" || !/^\d+$/.test(value)) return null;
  try {
    return BigInt(value);
  } catch {
    return null;
  }
}

export function parseQuote(payload: unknown): QuoteLeg | null {
  const record = asRecord(payload);
  if (!record || record.error) return null;
  const inAmount = rawAmount(record.inAmount);
  const outAmount = rawAmount(record.outAmount);
  if (inAmount === null || outAmount === null || inAmount <= 0n || outAmount <= 0n) return null;
  return { inAmount, outAmount };
}

export function judgeRoundTrip(spent: bigint, buy: QuoteLeg | null, sell: QuoteLeg | null): QuoteCheck {
  const hide = (reason: QuoteCheck["reason"]): QuoteCheck => ({
    status: "hide",
    reason,
    sellReturnPct: null,
  });
  if (spent <= 0n || !buy || !sell) return hide("unavailable");
  if (buy.inAmount !== spent || sell.inAmount !== buy.outAmount) return hide("unavailable");
  const sellReturnPct = Number((sell.outAmount * 1_000_000n) / spent) / 1_000_000;
  if (sell.outAmount * 10000n < spent * SELL_FLOOR_BPS) {
    return { status: "hide", reason: "sell", sellReturnPct };
  }
  return { status: "pass", reason: "pass", sellReturnPct };
}

export function quoteUrl(base: string, inputMint: string, outputMint: string, amount: bigint): string {
  const url = new URL(base);
  url.searchParams.set("inputMint", inputMint);
  url.searchParams.set("outputMint", outputMint);
  url.searchParams.set("amount", amount.toString());
  url.searchParams.set("slippageBps", "50");
  return url.toString();
}
