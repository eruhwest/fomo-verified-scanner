const SCORE_LIMIT = 5000;

export type RugCheck = {
  status: "pass" | "hide";
  reason: "pass" | "score" | "honeypot" | "authority" | "unavailable";
  score: number | null;
};

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function riskText(value: unknown): string {
  const record = asRecord(value);
  if (!record) return "";
  return [record.name, record.description, record.level].filter((item) => typeof item === "string").join(" ").toLowerCase();
}

function authorityWarning(text: string): boolean {
  if (!/(mint|freeze) authority/.test(text)) return false;
  if (/(not revoked|still|enabled|active)/.test(text)) return true;
  if (/(revoked|disabled|removed|absent)/.test(text)) return false;
  return true;
}

function authoritySet(value: unknown): boolean {
  if (value === null || value === undefined) return false;
  if (typeof value === "string") return value.trim().length > 0;
  return true;
}

export function judgeRug(payload: unknown): RugCheck {
  const hide = (reason: RugCheck["reason"], score: number | null = null): RugCheck => ({
    status: "hide",
    reason,
    score,
  });
  const record = asRecord(payload);
  if (!record || typeof record.score !== "number" || !Number.isFinite(record.score) || record.score < 0) {
    return hide("unavailable");
  }
  if (!Array.isArray(record.risks)) return hide("unavailable", record.score);
  if (record.rugged === true) return hide("honeypot", record.score);
  if (authoritySet(record.mintAuthority) || authoritySet(record.freezeAuthority)) {
    return hide("authority", record.score);
  }
  for (const risk of record.risks) {
    const text = riskText(risk);
    if (text.includes("honeypot")) return hide("honeypot", record.score);
    if (authorityWarning(text)) return hide("authority", record.score);
  }
  if (record.score >= SCORE_LIMIT) return hide("score", record.score);
  return { status: "pass", reason: "pass", score: record.score };
}
