import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import { env } from "../env.server.ts";
import { dexUrl, selectMainPair } from "./dex.ts";
import {
  applyOutcomes,
  needsOutcomePrice,
  parseOutcomeFile,
  toOutcomeRows,
  type OutcomeRecord,
  type OutcomeRow,
  type RankedSighting,
} from "./outcomes.ts";
import type { ServiceError } from "./types.ts";

const REQUEST_MS = 12_000;

function outcomeFile(): string {
  const custom = env("OUTCOMES_FILE");
  if (!custom) return path.join(process.cwd(), "data", "outcomes.json");
  return path.resolve(custom);
}

async function readRecords(): Promise<OutcomeRecord[]> {
  try {
    const text = await readFile(outcomeFile(), "utf8");
    return parseOutcomeFile(JSON.parse(text) as unknown);
  } catch (error) {
    const code = error && typeof error === "object" && "code" in error ? String(error.code) : "";
    if (code === "ENOENT") return [];
    if (error instanceof SyntaxError) return [];
    throw error;
  }
}

async function writeRecords(records: readonly OutcomeRecord[]): Promise<void> {
  const file = outcomeFile();
  await mkdir(path.dirname(file), { recursive: true });
  const temp = `${file}.tmp`;
  await writeFile(temp, JSON.stringify(records), "utf8");
  await rename(temp, file);
}

async function fetchPrices(mints: readonly string[]): Promise<{ prices: Map<string, number | null>; failed: boolean }> {
  const prices = new Map<string, number | null>();
  let failed = false;
  for (let index = 0; index < mints.length; index += 30) {
    const batch = mints.slice(index, index + 30);
    try {
      const response = await fetch(dexUrl(batch), {
        headers: { accept: "application/json" },
        signal: AbortSignal.timeout(REQUEST_MS),
      });
      if (!response.ok) {
        failed = true;
        continue;
      }
      const payload: unknown = await response.json();
      for (const mint of batch) {
        try {
          prices.set(mint, selectMainPair(mint, payload)?.priceUsd ?? null);
        } catch {
          prices.set(mint, null);
          failed = true;
        }
      }
    } catch {
      failed = true;
    }
  }
  return { prices, failed };
}

export async function syncOutcomes(
  ranked: readonly RankedSighting[],
): Promise<{ rows: OutcomeRow[]; errors: ServiceError[] }> {
  const now = Date.now();
  const errors: ServiceError[] = [];
  let existing: OutcomeRecord[] = [];
  try {
    existing = await readRecords();
  } catch {
    errors.push({ source: "outcomes", message: "The outcome file could not be read. No new prices were stored." });
    return { rows: [], errors };
  }

  const prices = new Map<string, number | null>();
  for (const sight of ranked) prices.set(sight.mint, sight.priceUsd);
  const due = existing.filter((record) => needsOutcomePrice(record, now) && !(typeof prices.get(record.mint) === "number" && (prices.get(record.mint) ?? 0) > 0));
  if (due.length > 0) {
    const found = await fetchPrices(due.map((record) => record.mint));
    for (const [mint, price] of found.prices) prices.set(mint, price);
    if (found.failed) {
      errors.push({
        source: "outcomes",
        message: "An outcome price request failed. Due checkpoints were left empty.",
      });
    }
  }

  const next = applyOutcomes(existing, ranked, prices, now);
  if (JSON.stringify(next) !== JSON.stringify(existing)) {
    try {
      await writeRecords(next);
    } catch {
      errors.push({ source: "outcomes", message: "The outcome file could not be saved." });
    }
  }
  return { rows: toOutcomeRows(next, now), errors };
}
