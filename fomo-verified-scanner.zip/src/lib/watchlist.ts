import { checkMint } from "./solana-address.ts";

export const WATCHLIST_STORAGE_KEY = "fomo-verified-scanner.watchlist.v1";
export const WATCHLIST_LIMIT = 100;

export type WatchItem = {
  mint: string;
  addedAt: string;
};

export type RejectedLine = {
  line: number;
  value: string;
  reason: string;
};

export type DuplicateLine = {
  line: number;
  mint: string;
};

export type ParseMintPasteResult = {
  accepted: string[];
  duplicates: DuplicateLine[];
  rejected: RejectedLine[];
};

export function parseMintPaste(
  text: string,
  existing: readonly string[],
  limit = WATCHLIST_LIMIT,
): ParseMintPasteResult {
  const accepted: string[] = [];
  const duplicates: DuplicateLine[] = [];
  const rejected: RejectedLine[] = [];
  const seen = new Set(existing);
  const lines = text.split(/\r?\n/);

  lines.forEach((raw, index) => {
    if (raw.trim() === "") return;
    const line = index + 1;
    const checked = checkMint(raw);
    if (!checked.ok) {
      rejected.push({ line, value: raw.trim(), reason: checked.reason });
      return;
    }
    if (seen.has(checked.mint)) {
      duplicates.push({ line, mint: checked.mint });
      return;
    }
    if (existing.length + accepted.length >= limit) {
      rejected.push({
        line,
        value: checked.mint,
        reason: `List holds ${limit} mints. Remove one before adding more.`,
      });
      return;
    }
    seen.add(checked.mint);
    accepted.push(checked.mint);
  });

  return { accepted, duplicates, rejected };
}

export function mergeWatchlist(
  existing: readonly WatchItem[],
  accepted: readonly string[],
  addedAt: string,
): WatchItem[] {
  const fresh = accepted.map((mint) => ({ mint, addedAt }));
  return [...fresh, ...existing];
}

export function isWatchItem(value: unknown): value is WatchItem {
  if (!value || typeof value !== "object") return false;
  const item = value as { mint?: unknown; addedAt?: unknown };
  if (typeof item.mint !== "string" || typeof item.addedAt !== "string") return false;
  return checkMint(item.mint).ok && !Number.isNaN(Date.parse(item.addedAt));
}

export function readWatchlist(storage: Pick<Storage, "getItem"> | null): WatchItem[] {
  if (!storage) return [];
  try {
    const raw = storage.getItem(WATCHLIST_STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const items = parsed.filter(isWatchItem);
    const seen = new Set<string>();
    const unique: WatchItem[] = [];
    for (const item of items) {
      if (seen.has(item.mint)) continue;
      seen.add(item.mint);
      unique.push(item);
      if (unique.length >= WATCHLIST_LIMIT) break;
    }
    return unique;
  } catch {
    return [];
  }
}

export function writeWatchlist(
  storage: Pick<Storage, "setItem"> | null,
  items: readonly WatchItem[],
): { ok: true } | { ok: false; reason: string } {
  if (!storage) {
    return { ok: false, reason: "This browser has no local storage. The list stays in this open tab only." };
  }
  try {
    storage.setItem(WATCHLIST_STORAGE_KEY, JSON.stringify(items));
    return { ok: true };
  } catch {
    return {
      ok: false,
      reason: "This browser blocked local storage. The list stays in this open tab only.",
    };
  }
}
