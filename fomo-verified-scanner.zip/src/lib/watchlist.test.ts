import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { checkMint, decodeBase58 } from "./solana-address.ts";
import { mergeWatchlist, parseMintPaste, readWatchlist, writeWatchlist } from "./watchlist.ts";

const USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
const WSOL = "So11111111111111111111111111111111111111112";

describe("checkMint", () => {
  it("accepts a 32-byte base58 address", () => {
    const decoded = decodeBase58(USDC);
    assert.ok(decoded);
    assert.equal(decoded.length, 32);
    assert.deepEqual(checkMint(`  ${USDC}  `), { ok: true, mint: USDC });
    assert.equal(checkMint(WSOL).ok, true);
  });

  it("rejects characters outside base58 and the wrong decoded length", () => {
    assert.equal(checkMint("0OIl" + "1".repeat(40)).ok, false);
    assert.equal(checkMint("not-a-mint").ok, false);
    assert.equal(checkMint("1111111111111111111111111111111").ok, false);
    const wrongLength = checkMint("2".repeat(40));
    assert.equal(wrongLength.ok, false);
    if (!wrongLength.ok) assert.match(wrongLength.reason, /32-byte/);
  });

  it("rejects extra text on the same line", () => {
    const result = checkMint(`${USDC} extra`);
    assert.equal(result.ok, false);
  });
});

describe("parseMintPaste", () => {
  it("de-duplicates against the saved list and within the paste", () => {
    const text = ["", USDC, WSOL, USDC, "bad", `${WSOL} note`].join("\n");
    const result = parseMintPaste(text, [USDC]);
    assert.deepEqual(result.accepted, [WSOL]);
    assert.equal(result.duplicates.length, 2);
    assert.equal(result.duplicates[0]?.mint, USDC);
    assert.equal(result.rejected.length, 2);
    assert.equal(result.rejected[0]?.line, 5);
    assert.equal(result.rejected[1]?.line, 6);
  });

  it("stops at the list limit", () => {
    const third = "11111111111111111111111111111111";
    const result = parseMintPaste([USDC, WSOL, third].join("\n"), [], 2);
    assert.deepEqual(result.accepted, [USDC, WSOL]);
    assert.equal(result.rejected.length, 1);
    assert.match(result.rejected[0]?.reason ?? "", /2 mints/);
  });
});

describe("watchlist storage", () => {
  it("round-trips valid rows and drops corrupt ones", () => {
    const memory = new Map<string, string>();
    const storage = {
      getItem: (key: string) => memory.get(key) ?? null,
      setItem: (key: string, value: string) => {
        memory.set(key, value);
      },
    };
    const items = mergeWatchlist([], [USDC], "2026-10-26T12:00:00.000Z");
    assert.deepEqual(writeWatchlist(storage, items), { ok: true });
    assert.deepEqual(readWatchlist(storage), items);

    memory.set(
      "fomo-verified-scanner.watchlist.v1",
      JSON.stringify([{ mint: "nope", addedAt: "2026-10-26T12:00:00.000Z" }, items[0], items[0]]),
    );
    assert.deepEqual(readWatchlist(storage), items);
  });
});
