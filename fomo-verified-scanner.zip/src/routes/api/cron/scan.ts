import { createFileRoute } from "@tanstack/react-router";
import { cronAuthorized } from "@/lib/scanner/config";

export const Route = createFileRoute("/api/cron/scan")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const { env } = await import("@/lib/env.server");
        if (!cronAuthorized(request.headers.get("authorization"), env("CRON_SECRET"))) {
          return new Response("Unauthorized", { status: 401 });
        }
        const { forceScan } = await import("@/lib/scanner/discover.server");
        const snapshot = await forceScan();
        return Response.json({
          ok: snapshot.serviceErrors.length === 0,
          scannedAt: snapshot.scannedAt,
          tokensScanned: snapshot.tokensScanned,
          hiddenByGates: snapshot.hiddenByGates,
          stale: snapshot.stale,
        });
      },
    },
  },
});
