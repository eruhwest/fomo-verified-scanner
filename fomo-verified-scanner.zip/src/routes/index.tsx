import { createFileRoute } from "@tanstack/react-router";
import { ScannerHome } from "@/components/scanner-home";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ScannerHome />;
}
